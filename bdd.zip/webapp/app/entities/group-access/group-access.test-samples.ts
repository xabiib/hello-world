import { IGroupAccess, NewGroupAccess } from './group-access.model';

export const sampleWithRequiredData: IGroupAccess = {
  id: 8530,
};

export const sampleWithPartialData: IGroupAccess = {
  id: 9103,
  name: 'bad',
};

export const sampleWithFullData: IGroupAccess = {
  id: 27736,
  name: 'below striped',
};

export const sampleWithNewData: NewGroupAccess = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
