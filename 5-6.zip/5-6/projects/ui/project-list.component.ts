import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from "@angular/core";
import { Project } from "../project.model";
import { MatTableDataSource, MatTableModule } from "@angular/material/table";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { DatePipe } from "@angular/common";
import { MatSort, MatSortModule, Sort } from "@angular/material/sort";
import { MatPaginator, MatPaginatorModule } from "@angular/material/paginator";
import { Router, RouterModule } from "@angular/router";

@Component({
  selector: "app-project-list",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    DatePipe,     MatSortModule, MatPaginatorModule, RouterModule
  ],
  templateUrl: './project-list.component.html',
  styleUrls: ['./project-list.component.scss'],
})
export class ProjectListComponent {
  @Input({ required: true }) projects!: Project[];
  @Output() delete = new EventEmitter<Project>();
  @Output() edit = new EventEmitter<Project>();
  @Output() add = new EventEmitter<Project>();

  
/*   @Output() sort = new EventEmitter<{
    sortColumn: string;
    sortDirection: "asc" | "desc";
  }>(); */

 // displayedColumns: string[] = ['name', 'category', 'price', 'status'];
  dataSource: MatTableDataSource<Project>;

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  displayedColumns = [
    "descriptionText",
    "privateInd",
    "lastUpdateDate",
   // "lastupdatedby",
    "userId",
    "action"
  ];

  ngOnInit() {
    console.log('@@@@ ' + this.projects) ;
    this.dataSource = new MatTableDataSource(this.projects);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  ngOnChanges(): void {
    this.dataSource = new MatTableDataSource(this.projects);
    }

  constructor(protected router: Router) {}

  onSortData(sortData: Sort) {
    const sortColumn = sortData.active;
    const sortDirection = sortData.direction as "asc" | "desc";
   // this.sort.emit({ sortColumn, sortDirection });
  }

  navigateToClaims(id:any) {
    this.router.navigateByUrl('/claims/' + id)
  }

  loadClaimsByProjectID(id:any) {
    console.log('@@@@@@@@@@@@@' + id) ;
  }

}
