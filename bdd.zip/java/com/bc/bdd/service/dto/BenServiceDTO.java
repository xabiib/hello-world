package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.BenService} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class BenServiceDTO implements Serializable {

    private Long id;

    private Boolean pay;

    @Size(max = 100)
    private String limit;

    private Long copay;

    private Boolean deductible;

    private Long coinsurance;

    private BenefitDTO benefit;

    private BenServiceListDTO benServiceList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getPay() {
        return pay;
    }

    public void setPay(Boolean pay) {
        this.pay = pay;
    }

    public String getLimit() {
        return limit;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public Long getCopay() {
        return copay;
    }

    public void setCopay(Long copay) {
        this.copay = copay;
    }

    public Boolean getDeductible() {
        return deductible;
    }

    public void setDeductible(Boolean deductible) {
        this.deductible = deductible;
    }

    public Long getCoinsurance() {
        return coinsurance;
    }

    public void setCoinsurance(Long coinsurance) {
        this.coinsurance = coinsurance;
    }

    public BenefitDTO getBenefit() {
        return benefit;
    }

    public void setBenefit(BenefitDTO benefit) {
        this.benefit = benefit;
    }

    public BenServiceListDTO getBenServiceList() {
        return benServiceList;
    }

    public void setBenServiceList(BenServiceListDTO benServiceList) {
        this.benServiceList = benServiceList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BenServiceDTO)) {
            return false;
        }

        BenServiceDTO benServiceDTO = (BenServiceDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, benServiceDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "BenServiceDTO{" +
            "id=" + getId() +
            ", pay='" + getPay() + "'" +
            ", limit='" + getLimit() + "'" +
            ", copay=" + getCopay() +
            ", deductible='" + getDeductible() + "'" +
            ", coinsurance=" + getCoinsurance() +
            ", benefit=" + getBenefit() +
            ", benServiceList=" + getBenServiceList() +
            "}";
    }
}
