import { Routes } from "@angular/router";
import { HomeComponent } from "./home.component";

export const routes: Routes = [
  {
    path: "home",
    component: HomeComponent,
  },
  {
    path: "projects",
    loadComponent() {
      return import("./projects/project.component").then(
        (a) => a.ProjectComponent
      );
    },
  },
  {
    // ClaimComponent
    path: "claims",
    loadComponent() {
      return import("./claim/claim.component").then(
        (a) => a.ClaimComponent
      );
    },
  },
  {
    // ClaimComponent
    path: "test",
    loadComponent() {
      return import("./test/complex-form.component").then(
        (a) => a.ComplexFormComponent
      );
    },
  },

  {
    path: "",
    redirectTo: "/home",
    pathMatch: "full",
  }, 
  {
    path: "**",
    loadComponent() {
      return import("./not-found.component").then((a) => a.NotFoundComponent);
    },
  },
];
