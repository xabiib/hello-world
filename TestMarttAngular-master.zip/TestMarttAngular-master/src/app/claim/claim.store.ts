import { Injectable, inject } from "@angular/core";
import { PaginatedClaim, Claim } from "./claim.model";
import { HttpErrorResponse } from "@angular/common/http";
import {
  ComponentStore,
  OnStateInit,
  tapResponse,
} from "@ngrx/component-store";
import { ClaimService } from "./claim.service";
import { combineLatest, exhaustMap, switchMap, tap } from "rxjs";

interface ClaimState {
  claims: Claim[];
  productName: string | null; // search filter
  dateFrom: string | null; // date filter
  dateTo: string | null; // date filter
  sortColumn: string;
  sortDirection: "asc" | "desc";
  page: number;
  limit: number;
  totalRecords: number;
  loading: boolean;
  error: HttpErrorResponse | null;
}

const initialState: ClaimState = {
  claims: [],
  productName: null,
  dateFrom: null,
  dateTo: null,
  sortColumn: "Id",
  sortDirection: "asc",
  page: 1,
  limit: 5,
  totalRecords: 0,
  loading: false,
  error: null,
};

@Injectable()
export class ClaimStore
  extends ComponentStore<ClaimState>
  implements OnStateInit
{
  private readonly claimService = inject(ClaimService);

  private readonly claims$ = this.select((s) => s.claims);
  private readonly productName$ = this.select((s) => s.productName);
  private readonly dateFrom$ = this.select((s) => s.dateFrom);
  private readonly dateTo$ = this.select((s) => s.dateTo);
  private readonly sortColumn$ = this.select((s) => s.sortColumn);
  private readonly sortDirection$ = this.select((s) => s.sortDirection);
  private readonly page$ = this.select((s) => s.page);
  private readonly limit$ = this.select((s) => s.limit);
  private readonly totalRecords$ = this.select((s) => s.totalRecords);
  private readonly loading$ = this.select((s) => s.loading);
  private readonly error$ = this.select((s) => s.error);

  readonly vm$ = this.select({
    claims: this.claims$,
    productName: this.productName$,
    dateFrom: this.dateFrom$,
    dateTo: this.dateTo$,
    sortColumn: this.sortColumn$,
    sortDirection: this.sortDirection$,
    page: this.page$,
    limit: this.limit$,
    totalRecords: this.totalRecords$,
    loading: this.loading$,
    error: this.error$,
  });

  private setLoading = this.updater((state) => ({
    ...state,
    loading: true,
  }));
  private setError = this.updater((state, error: HttpErrorResponse) => ({
    ...state,
    loading: false,
    error,
  }));

  private addSingleClaimToState = this.updater(
    (state, claim: Claim) => ({
      ...state,
      loading: false,
      claims: [...state.claims, claim],
    })
  );

  private loadClaimToState = this.updater(
    (state, claims: Claim[]) => {
      const updatedState = {
        ...state,
        loading: false,
        claims,
      };
      return updatedState;
    }
  );

  private updateClaimFromState = this.updater(
    (state, claim: Claim) => ({
      ...state,
      loading: false,
      claims: state.claims.map((p) =>
        p.id === claim.id ? claim : p
      ),
    })
  );

  private deleteClaimFromModel = this.updater((state, id: number) => {
    // console.log({ beforeDelete: state.Claims.map((a) => a.productName) });
    //console.log(id);
    const updatedRecords = state.claims.filter((p) => p.id !== id);
    const updatedState = {
      ...state,
      loading: false,
      claims: updatedRecords,
    };
    // console.log({
    //   afterDelete: updatedState.Claims.map((a) => a.productName),
    // });
    return updatedState;
  });

  setProductName = this.updater((state, descriptiontext: string | null) => ({
    ...state,
    descriptiontext,
  }));

  setDateFilter = this.updater(
    (
      state,
      dateParams: { dateFrom: string | null; dateTo: string | null }
    ) => ({
      ...state,
      dateFrom: dateParams.dateFrom,
      dateTo: dateParams.dateTo,
    })
  );

  setPage = this.updater((state, page: number) => ({
    ...state,
    page,
  }));

  setLimit = this.updater((state, limit: number) => ({
    ...state,
    limit,
  }));

  setTotalRecords = this.updater((state, totalRecords: number) => ({
    ...state,
    totalRecords,
  }));

  setSortColumn = this.updater((state, sortColumn: string) => ({
    ...state,
    sortColumn,
  }));

  setSortDirection = this.updater((state, sortDirection: "asc" | "desc") => ({
    ...state,
    sortDirection,
  }));

  readonly loadClaims = this.effect<void>((trigger$) =>
    trigger$.pipe(
      tap(() => this.setLoading()),
      exhaustMap(() => {
        const combinedStream$ = combineLatest([
          this.page$,
          this.limit$,
          this.productName$,
          this.dateFrom$,
          this.dateTo$,
          this.sortColumn$,
          this.sortDirection$,
        ]);
        return combinedStream$.pipe(
          switchMap(
            ([
              page,
              limit,
              productName,
              dateFrom,
              dateTo,
              sortColumn,
              sortDirection,
            ]) => {
              return this.claimService
                .getAll(
                  page,
                  limit,
                  productName,
                  dateFrom,
                  dateTo,
                  sortColumn,
                  sortDirection
                )
                .pipe(
                  tapResponse(
                    (response) => {
                      this.handleClaimResponse(response);
                    },
                    (error: HttpErrorResponse) => {
                      this.setError(error);
                    }
                  )
                );
            }
          )
        );
      })
    )
  );

  private handleClaimResponse = (response: PaginatedClaim) => {
    this.setPage(response.Page);
    this.setLimit(response.Limit);
    this.setTotalRecords(response.TotalRecords);
    this.loadClaimToState(response.claims);
  };

  readonly addClaim = this.effect<Claim>((trigger$) =>
    trigger$.pipe(
      tap((_) => this.setLoading()),
      switchMap((Claim) =>
        this.claimService.add(Claim).pipe(
          tapResponse(
            (response) => this.addSingleClaimToState(response),
            (error: HttpErrorResponse) => this.setError(error)
          )
        )
      )
    )
  );
  readonly updateClaim = this.effect<Claim>((trigger$) =>
    trigger$.pipe(
      tap((_) => this.setLoading()),
      switchMap((Claim) =>
        this.claimService.update(Claim).pipe(
          tapResponse(
            (response) => this.updateClaimFromState(response),
            (error: HttpErrorResponse) => this.setError(error)
          )
        )
      )
    )
  );

  readonly deleteClaim = this.effect<number>((id$) =>
    id$.pipe(
      tap((_) => this.setLoading()),
      switchMap((id) =>
        this.claimService.delete(id).pipe(
          tapResponse(
            () => this.deleteClaimFromModel(id),
            (error: HttpErrorResponse) => this.setError(error)
          )
        )
      )
    )
  );

  constructor() {
    super(initialState);
  }
  ngrxOnStateInit() {
    this.loadClaims();
  }
}
