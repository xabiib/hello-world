package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.Plan} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class PlanDTO implements Serializable {

    private Long id;

    @NotNull
    @Size(max = 100)
    private String name;

    private CostShareDTO costShare;

    private BenServiceListDTO benServiceList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public CostShareDTO getCostShare() {
        return costShare;
    }

    public void setCostShare(CostShareDTO costShare) {
        this.costShare = costShare;
    }

    public BenServiceListDTO getBenServiceList() {
        return benServiceList;
    }

    public void setBenServiceList(BenServiceListDTO benServiceList) {
        this.benServiceList = benServiceList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PlanDTO)) {
            return false;
        }

        PlanDTO planDTO = (PlanDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, planDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "PlanDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", costShare=" + getCostShare() +
            ", benServiceList=" + getBenServiceList() +
            "}";
    }
}
