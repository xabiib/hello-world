package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.PackagePlan} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class PackagePlanDTO implements Serializable {

    private Long id;

    @Size(max = 100)
    private String name;

    private LocalDate effective;

    private LocalDate termination;

    private Instant date;

    @Size(max = 10)
    private String status;

    private PackageCodeDTO packagecode;

    private UserDTO user;

    private PlanDTO plan;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getEffective() {
        return effective;
    }

    public void setEffective(LocalDate effective) {
        this.effective = effective;
    }

    public LocalDate getTermination() {
        return termination;
    }

    public void setTermination(LocalDate termination) {
        this.termination = termination;
    }

    public Instant getDate() {
        return date;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public PackageCodeDTO getPackagecode() {
        return packagecode;
    }

    public void setPackagecode(PackageCodeDTO packagecode) {
        this.packagecode = packagecode;
    }

    public UserDTO getUser() {
        return user;
    }

    public void setUser(UserDTO user) {
        this.user = user;
    }

    public PlanDTO getPlan() {
        return plan;
    }

    public void setPlan(PlanDTO plan) {
        this.plan = plan;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PackagePlanDTO)) {
            return false;
        }

        PackagePlanDTO packagePlanDTO = (PackagePlanDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, packagePlanDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "PackagePlanDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", effective='" + getEffective() + "'" +
            ", termination='" + getTermination() + "'" +
            ", date='" + getDate() + "'" +
            ", status='" + getStatus() + "'" +
            ", packagecode=" + getPackagecode() +
            ", user=" + getUser() +
            ", plan=" + getPlan() +
            "}";
    }
}
