import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import BenServiceResolve from './route/ben-service-routing-resolve.service';

const benServiceRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/ben-service.component').then(m => m.BenServiceComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/ben-service-detail.component').then(m => m.BenServiceDetailComponent),
    resolve: {
      benService: BenServiceResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/ben-service-update.component').then(m => m.BenServiceUpdateComponent),
    resolve: {
      benService: BenServiceResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    loadComponent: () => import('./update/ben-service-update.component').then(m => m.BenServiceUpdateComponent),
    resolve: {
      benService: BenServiceResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default benServiceRoute;
