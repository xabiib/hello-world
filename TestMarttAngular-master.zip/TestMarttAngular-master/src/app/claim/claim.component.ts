import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  inject,
} from "@angular/core";
import { provideComponentStore } from "@ngrx/component-store";
import { ClaimStore } from "./claim.store";
import { AsyncPipe, JsonPipe, NgIf } from "@angular/common";
import { ClaimListComponent } from "./ui/claim-list.component";
import { capitalize } from "../utils/init-cap.util";
import { Claim } from "./claim.model";
import { ClaimPaginatorComponent } from "./ui/claim-pagination.component";
import { ClaimFilters } from "./ui/claim-filters.component";
import { MatButtonModule } from "@angular/material/button";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { Observable, Subject, map, takeUntil, tap } from "rxjs";
import { ClaimDialogComponent } from "./ui/claim-dialog.component";
import { MatDialog, MatDialogModule } from "@angular/material/dialog";
//import { ProductService } from "../products/product.service";
import { Project } from "../projects/project.model";
//import { ProjectService } from "../projects/project.service";
import { ProjectStore } from "../projects/project.store";
//import { ProductWithStock } from "../products/product-with-stock.model";

@Component({
  selector: "app-Claim",
  standalone: true,
  imports: [
    AsyncPipe,
    JsonPipe,
    ClaimListComponent,
    NgIf,
    ClaimPaginatorComponent,
    ClaimFilters,
    MatButtonModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    AsyncPipe
  ],
 // changeDetection: ChangeDetectionStrategy.OnPush,
  providers: [provideComponentStore(ClaimStore) ,  provideComponentStore(ProjectStore),],
  styles: [``],
  template: `
     <ng-container > 
      <div style="display: flex;align-items:center;gap:5px;margin-bottom:8px">
        <span style="font-size: 26px;font-weight:bold"> Claims </span>
        <button
          mat-raised-button
          color="primary"
          (click)="onAddUpdate('Add Claim')"
        >
          Add More
        </button>
      </div>
 <!--      <ng-container *ngIf="this.claimStore.vm$ | async as vm">
        <div *ngIf="vm.loading" class="spinner-center">
          <mat-spinner diameter="50"></mat-spinner>
        </div>
        <div *ngIf="vm.claims && vm.claims.length > 0">
          <app-claim-filters
            (searchProduct)="onSearch($event)"
            (filterByClaimDate)="onDateFilter($event)"
            (clearFilter)="onClearFilter()"
          />
          <app-claim-list
            [claims]="vm.claims"
            (sort)="onSort($event)"
            (delete)="onDelete($event)"
            (edit)="onAddUpdate('Edit Claim')"
          />

          <app-claim-paginator
            [totalRecords]="vm.totalRecords"
            (pageSelect)="onPageSelect($event)"
          />
        </div>
        <ng-template #no_records>
          <p style="margin-top:20px;font-size:21px">
            No records found
          </p></ng-template
        >
      </ng-container> -->
     </ng-container> 
  `,
})
export class ClaimComponent implements OnDestroy {
  claimStore = inject(ClaimStore);
  projectStore = inject(ProjectStore);

  vm$ = this.claimStore.vm$;
  //productService = inject(ProjectService);

  //products$: Observable<Project[]> = this.productService.getProjects();

  dialog = inject(MatDialog);
  destroyed$ = new Subject<boolean>();
  onSort(sortData: { sortColumn: string; sortDirection: "asc" | "desc" }) {
    this.claimStore.setSortColumn(capitalize(sortData.sortColumn));
    this.claimStore.setSortDirection(sortData.sortDirection);
  }

  onPageSelect(pageData: { page: number; limit: number }) {
    this.claimStore.setPage(pageData.page);
    this.claimStore.setLimit(pageData.limit);
  }

  onSearch(descriptiontext: string | null) {
    this.claimStore.setProductName(descriptiontext);
  }

  onDateFilter(dateRange: { dateFrom: string | null; dateTo: string | null }) {
    if (dateRange.dateFrom && dateRange.dateTo) {
      this.claimStore.setDateFilter({ ...dateRange });
    }
  }

  onClearFilter() {
    this.claimStore.setDateFilter({ dateFrom: null, dateTo: null });
    this.claimStore.setProductName(null);
  }
  onAddUpdate(
    action: string,
    claim: Claim | null = null //,    products: ProductWithStock[]
  ) {
    let projects : Project[] =[] ;
    this.projectStore.vm$.pipe(
      takeUntil(this.destroyed$),
        tap((a) => {
          projects = a.projects
        })
    )
        .subscribe();
        const dialogRef = this.dialog.open(ClaimDialogComponent, {
          data: { claim, title: action + " Project", projects },
        }
    )
  /*   const dialogRef = this.dialog.open(ClaimDialogComponent, {
      data: { claim, title: action + " Book", products },
    }); */

    dialogRef.componentInstance.sumbit
      .pipe(takeUntil(this.destroyed$))
      .subscribe((submittedClaim) => {
        if (!submittedClaim) return;
        if (submittedClaim.id && submittedClaim.id > 0) {
          // update book
          this.claimStore.updateClaim(submittedClaim);
        } else {
          // add book
          this.claimStore.addClaim(submittedClaim);
        }
        dialogRef.componentInstance.claimForm.reset();
        dialogRef.componentInstance.onCanceled();
      });
  }

  onDelete(claim: Claim) {
    if (window.confirm("Are you sure to delete??")) {
      this.claimStore.deleteClaim(claim.id);
    }
  }

  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.unsubscribe();
  }
}
