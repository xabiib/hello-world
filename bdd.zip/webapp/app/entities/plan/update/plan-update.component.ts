import { Component, OnInit, inject } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import SharedModule from 'app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ICostShare } from 'app/entities/cost-share/cost-share.model';
import { CostShareService } from 'app/entities/cost-share/service/cost-share.service';
import { IBenServiceList } from 'app/entities/ben-service-list/ben-service-list.model';
import { BenServiceListService } from 'app/entities/ben-service-list/service/ben-service-list.service';
import { PlanService } from '../service/plan.service';
import { IPlan } from '../plan.model';
import { PlanFormGroup, PlanFormService } from './plan-form.service';

@Component({
  standalone: true,
  selector: 'jhi-plan-update',
  templateUrl: './plan-update.component.html',
  imports: [SharedModule, FormsModule, ReactiveFormsModule],
})
export class PlanUpdateComponent implements OnInit {
  isSaving = false;
  plan: IPlan | null = null;

  costSharesSharedCollection: ICostShare[] = [];
  benServiceListsSharedCollection: IBenServiceList[] = [];

  protected planService = inject(PlanService);
  protected planFormService = inject(PlanFormService);
  protected costShareService = inject(CostShareService);
  protected benServiceListService = inject(BenServiceListService);
  protected activatedRoute = inject(ActivatedRoute);

  // eslint-disable-next-line @typescript-eslint/member-ordering
  editForm: PlanFormGroup = this.planFormService.createPlanFormGroup();

  compareCostShare = (o1: ICostShare | null, o2: ICostShare | null): boolean => this.costShareService.compareCostShare(o1, o2);

  compareBenServiceList = (o1: IBenServiceList | null, o2: IBenServiceList | null): boolean =>
    this.benServiceListService.compareBenServiceList(o1, o2);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ plan }) => {
      this.plan = plan;
      if (plan) {
        this.updateForm(plan);
      }

      this.loadRelationshipsOptions();
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const plan = this.planFormService.getPlan(this.editForm);
    if (plan.id !== null) {
      this.subscribeToSaveResponse(this.planService.update(plan));
    } else {
      this.subscribeToSaveResponse(this.planService.create(plan));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IPlan>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(plan: IPlan): void {
    this.plan = plan;
    this.planFormService.resetForm(this.editForm, plan);

    this.costSharesSharedCollection = this.costShareService.addCostShareToCollectionIfMissing<ICostShare>(
      this.costSharesSharedCollection,
      plan.costShare,
    );
    this.benServiceListsSharedCollection = this.benServiceListService.addBenServiceListToCollectionIfMissing<IBenServiceList>(
      this.benServiceListsSharedCollection,
      plan.benServiceList,
    );
  }

  protected loadRelationshipsOptions(): void {
    this.costShareService
      .query()
      .pipe(map((res: HttpResponse<ICostShare[]>) => res.body ?? []))
      .pipe(
        map((costShares: ICostShare[]) =>
          this.costShareService.addCostShareToCollectionIfMissing<ICostShare>(costShares, this.plan?.costShare),
        ),
      )
      .subscribe((costShares: ICostShare[]) => (this.costSharesSharedCollection = costShares));

    this.benServiceListService
      .query()
      .pipe(map((res: HttpResponse<IBenServiceList[]>) => res.body ?? []))
      .pipe(
        map((benServiceLists: IBenServiceList[]) =>
          this.benServiceListService.addBenServiceListToCollectionIfMissing<IBenServiceList>(benServiceLists, this.plan?.benServiceList),
        ),
      )
      .subscribe((benServiceLists: IBenServiceList[]) => (this.benServiceListsSharedCollection = benServiceLists));
  }
}
