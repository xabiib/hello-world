import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import dayjs from 'dayjs/esm';
import { DATE_TIME_FORMAT } from 'app/config/input.constants';
import { IPackagePlan, NewPackagePlan } from '../package-plan.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts IPackagePlan for edit and NewPackagePlanFormGroupInput for create.
 */
type PackagePlanFormGroupInput = IPackagePlan | PartialWithRequiredKeyOf<NewPackagePlan>;

/**
 * Type that converts some properties for forms.
 */
type FormValueOf<T extends IPackagePlan | NewPackagePlan> = Omit<T, 'date'> & {
  date?: string | null;
};

type PackagePlanFormRawValue = FormValueOf<IPackagePlan>;

type NewPackagePlanFormRawValue = FormValueOf<NewPackagePlan>;

type PackagePlanFormDefaults = Pick<NewPackagePlan, 'id' | 'date'>;

type PackagePlanFormGroupContent = {
  id: FormControl<PackagePlanFormRawValue['id'] | NewPackagePlan['id']>;
  name: FormControl<PackagePlanFormRawValue['name']>;
  effective: FormControl<PackagePlanFormRawValue['effective']>;
  termination: FormControl<PackagePlanFormRawValue['termination']>;
  date: FormControl<PackagePlanFormRawValue['date']>;
  status: FormControl<PackagePlanFormRawValue['status']>;
  packagecode: FormControl<PackagePlanFormRawValue['packagecode']>;
  user: FormControl<PackagePlanFormRawValue['user']>;
  plan: FormControl<PackagePlanFormRawValue['plan']>;
};

export type PackagePlanFormGroup = FormGroup<PackagePlanFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class PackagePlanFormService {
  createPackagePlanFormGroup(packagePlan: PackagePlanFormGroupInput = { id: null }): PackagePlanFormGroup {
    const packagePlanRawValue = this.convertPackagePlanToPackagePlanRawValue({
      ...this.getFormDefaults(),
      ...packagePlan,
    });
    return new FormGroup<PackagePlanFormGroupContent>({
      id: new FormControl(
        { value: packagePlanRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        },
      ),
      name: new FormControl(packagePlanRawValue.name, {
        validators: [Validators.maxLength(100)],
      }),
      effective: new FormControl(packagePlanRawValue.effective),
      termination: new FormControl(packagePlanRawValue.termination),
      date: new FormControl(packagePlanRawValue.date),
      status: new FormControl(packagePlanRawValue.status, {
        validators: [Validators.maxLength(10)],
      }),
      packagecode: new FormControl(packagePlanRawValue.packagecode),
      user: new FormControl(packagePlanRawValue.user),
      plan: new FormControl(packagePlanRawValue.plan),
    });
  }

  getPackagePlan(form: PackagePlanFormGroup): IPackagePlan | NewPackagePlan {
    return this.convertPackagePlanRawValueToPackagePlan(form.getRawValue() as PackagePlanFormRawValue | NewPackagePlanFormRawValue);
  }

  resetForm(form: PackagePlanFormGroup, packagePlan: PackagePlanFormGroupInput): void {
    const packagePlanRawValue = this.convertPackagePlanToPackagePlanRawValue({ ...this.getFormDefaults(), ...packagePlan });
    form.reset(
      {
        ...packagePlanRawValue,
        id: { value: packagePlanRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */,
    );
  }

  private getFormDefaults(): PackagePlanFormDefaults {
    const currentTime = dayjs();

    return {
      id: null,
      date: currentTime,
    };
  }

  private convertPackagePlanRawValueToPackagePlan(
    rawPackagePlan: PackagePlanFormRawValue | NewPackagePlanFormRawValue,
  ): IPackagePlan | NewPackagePlan {
    return {
      ...rawPackagePlan,
      date: dayjs(rawPackagePlan.date, DATE_TIME_FORMAT),
    };
  }

  private convertPackagePlanToPackagePlanRawValue(
    packagePlan: IPackagePlan | (Partial<NewPackagePlan> & PackagePlanFormDefaults),
  ): PackagePlanFormRawValue | PartialWithRequiredKeyOf<NewPackagePlanFormRawValue> {
    return {
      ...packagePlan,
      date: packagePlan.date ? packagePlan.date.format(DATE_TIME_FORMAT) : undefined,
    };
  }
}
