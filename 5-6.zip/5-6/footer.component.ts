import { ChangeDetectionStrategy, Component } from "@angular/core";
import { MatToolbarModule } from "@angular/material/toolbar";

@Component({
  selector: "app-footer",
  standalone: true,
  imports: [MatToolbarModule],
  template: `
    <mat-toolbar color="primary" class="footer-toolbar">
    <span>© 2024 BCBSM TestMart Tool. All rights reserved.</span>
    <span class="spacer"></span>
    <span>Contact Us: test&#64;test.com</span>
  </mat-toolbar>
  `,
  styles: [
    `  
    :host {
        padding: 10px 0px;
        text-align: center;
        font-size: 12px;
      }
  .footer-toolbar {
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 20px; /* Adjust based on your content */
    display: flex;
    justify-content: space-between;
    align-items: center;
  }
  .spacer {
    flex: 1 1 auto;
  }
  
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FooterComponent {}
