import { ICostShare } from 'app/entities/cost-share/cost-share.model';
import { IBenServiceList } from 'app/entities/ben-service-list/ben-service-list.model';

export interface IPlan {
  id: number;
  name?: string | null;
  costShare?: Pick<ICostShare, 'id'> | null;
  benServiceList?: Pick<IBenServiceList, 'id'> | null;
}

export type NewPlan = Omit<IPlan, 'id'> & { id: null };
