import { IGroup } from 'app/entities/group/group.model';

export interface ISection {
  id: number;
  name?: string | null;
  num?: string | null;
  active?: boolean | null;
  group?: Pick<IGroup, 'id' | 'num'> | null;
}

export type NewSection = Omit<ISection, 'id'> & { id: null };
