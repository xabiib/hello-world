import { ISection, NewSection } from './section.model';

export const sampleWithRequiredData: ISection = {
  id: 12153,
  num: 'slim',
};

export const sampleWithPartialData: ISection = {
  id: 9839,
  num: 'smud',
  active: false,
};

export const sampleWithFullData: ISection = {
  id: 26695,
  name: 'instead',
  num: 'tabl',
  active: true,
};

export const sampleWithNewData: NewSection = {
  num: 'aw r',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
