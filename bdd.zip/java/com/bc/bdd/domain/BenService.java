package com.bc.bdd.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;

/**
 * A BenService.
 */
@Entity
@Table(name = "ben_service")
@SuppressWarnings("common-java:DuplicatedBlocks")
public class BenService implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @Column(name = "pay")
    private Boolean pay;

    @Size(max = 100)
    @Column(name = "jhi_limit", length = 100)
    private String limit;

    @Column(name = "copay")
    private Long copay;

    @Column(name = "deductible")
    private Boolean deductible;

    @Column(name = "coinsurance")
    private Long coinsurance;

    @JsonIgnoreProperties(value = { "benService" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private Benefit benefit;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "benServices", "plans" }, allowSetters = true)
    private BenServiceList benServiceList;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public BenService id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Boolean getPay() {
        return this.pay;
    }

    public BenService pay(Boolean pay) {
        this.setPay(pay);
        return this;
    }

    public void setPay(Boolean pay) {
        this.pay = pay;
    }

    public String getLimit() {
        return this.limit;
    }

    public BenService limit(String limit) {
        this.setLimit(limit);
        return this;
    }

    public void setLimit(String limit) {
        this.limit = limit;
    }

    public Long getCopay() {
        return this.copay;
    }

    public BenService copay(Long copay) {
        this.setCopay(copay);
        return this;
    }

    public void setCopay(Long copay) {
        this.copay = copay;
    }

    public Boolean getDeductible() {
        return this.deductible;
    }

    public BenService deductible(Boolean deductible) {
        this.setDeductible(deductible);
        return this;
    }

    public void setDeductible(Boolean deductible) {
        this.deductible = deductible;
    }

    public Long getCoinsurance() {
        return this.coinsurance;
    }

    public BenService coinsurance(Long coinsurance) {
        this.setCoinsurance(coinsurance);
        return this;
    }

    public void setCoinsurance(Long coinsurance) {
        this.coinsurance = coinsurance;
    }

    public Benefit getBenefit() {
        return this.benefit;
    }

    public void setBenefit(Benefit benefit) {
        this.benefit = benefit;
    }

    public BenService benefit(Benefit benefit) {
        this.setBenefit(benefit);
        return this;
    }

    public BenServiceList getBenServiceList() {
        return this.benServiceList;
    }

    public void setBenServiceList(BenServiceList benServiceList) {
        this.benServiceList = benServiceList;
    }

    public BenService benServiceList(BenServiceList benServiceList) {
        this.setBenServiceList(benServiceList);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BenService)) {
            return false;
        }
        return getId() != null && getId().equals(((BenService) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "BenService{" +
            "id=" + getId() +
            ", pay='" + getPay() + "'" +
            ", limit='" + getLimit() + "'" +
            ", copay=" + getCopay() +
            ", deductible='" + getDeductible() + "'" +
            ", coinsurance=" + getCoinsurance() +
            "}";
    }
}
