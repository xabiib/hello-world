import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  inject,
} from "@angular/core";
import { provideComponentStore } from "@ngrx/component-store";
import { ProjectStore } from "./project.store";
import { AsyncPipe, NgFor, NgIf } from "@angular/common";
import { Project } from "./project.model";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatDialog } from "@angular/material/dialog";
import { Subject, takeUntil, tap } from "rxjs";
import { MatButtonModule } from "@angular/material/button";
import { capitalize } from "../utils/init-cap.util";
import {ProjectDialogComponent} from './ui/project-dialog.component';
import {ProjectListComponent} from './ui/project-list.component';
import {ProjectFilterComponent} from './ui/project-filter.component' ;
import {ProjectPaginatorComponent} from './ui/project-paginator.component' ;

@Component({
  selector: "app-project",
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    AsyncPipe,
    ProjectListComponent,
    ProjectFilterComponent,
    ProjectPaginatorComponent,
    MatProgressSpinnerModule,
    MatButtonModule,
  ],
  providers: [
    provideComponentStore(ProjectStore),
  ],
  template: `
    <div style="display: flex;align-items:center;gap:5px;margin-bottom:8px">
      <span style="font-size: 26px;font-weight:bold"> Projects </span>
      <button
        mat-raised-button
        color="primary"
        (click)="onAddUpdate('Add Project')"
      >
        Add More
      </button>
    </div>
    <ng-container *ngIf="vm$ | async as vm" style="position: relative;">
      <div *ngIf="vm.loading" class="spinner-center">
        <mat-spinner diameter="50"></mat-spinner>
      </div>
      <app-project-filter (filter)="onSearch($event)" />
      <div *ngIf="vm.projects && vm.projects.length > 0; else no_records">
        <app-project-list
          [projects]="vm.projects"
          (edit)="onAddUpdate('Update Project', $event)"
          (delete)="onDelete($event)"
          (sort)="onSort($event)"
        />
        <app-project-paginator
          (pageSelect)="onPageSelect($event)"
          [totalRecords]="vm.totalRecords"
        />
      </div>
      <ng-template #no_records>
        <p style="margin-top:20px;font-size:21px">
          No records found
        </p></ng-template
      >
    </ng-container>
  `,
  styles: [``],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProjectComponent implements OnDestroy {
  projectStore = inject(ProjectStore);
  dialog = inject(MatDialog);
  destroyed$ = new Subject<boolean>();
  vm$ = this.projectStore.vm$;

  onPageSelect(pageData: { page: number; limit: number }) {
    this.projectStore.setPage(pageData.page);
    this.projectStore.setPageLimit(pageData.limit);
  }

  onSearch(search: string | null) {
    console.log('@@@@@@  onSearch @@@@@@ BEFORE' ) ;
    this.projectStore.setSearchTerm(search);
    console.log('@@@@@@  onSearch @@@@@@ AFter' ) ;
  }

  onDelete(project: Project) {
    if (confirm("Are you sure to delete?")) {
      this.projectStore.deleteProject(project.claimScenarioId);
    }
    // console.log(product);
  }

  onAddUpdate(action: string, project: Project | null = null) {
    /* let categories: CategoryModel[] = [];
    this.categoryStore.vm$
      .pipe(
        takeUntil(this.destroyed$),
        tap((a) => {
          categories = a.categories;
        })
      )
      .subscribe(); */
    const dialogRef = this.dialog.open(ProjectDialogComponent, {
      data: { project },
    });

    dialogRef.componentInstance.sumbit
      .pipe(takeUntil(this.destroyed$))
      .subscribe((submittedProject) => {
        if (!submittedProject) return;
        if (submittedProject.claimScenarioId && submittedProject.claimScenarioId > 0) {
          // update book
          //console.log("update");
          this.projectStore.updateProject(submittedProject);
        } else {
          // add book
          //console.log(submittedProject);
          this.projectStore.addProject(submittedProject);
        }
        dialogRef.componentInstance.projectForm.reset();
        dialogRef.componentInstance.onCanceled();
      });
  }

  onSort(sortObj: { sortColumn: string; sortDirection: "asc" | "desc" }) {
   console.log('@@@@@@@@@@@@' + sortObj  ) ;
    this.projectStore.setSortDirection(sortObj.sortDirection);
    this.projectStore.setSortColumn(capitalize(sortObj.sortColumn));
  }

  constructor() {}
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.unsubscribe();
  }
}
