package com.bc.bdd.repository;

import com.bc.bdd.domain.PackageCode;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the PackageCode entity.
 */
@Repository
public interface PackageCodeRepository extends JpaRepository<PackageCode, Long> {
    default Optional<PackageCode> findOneWithEagerRelationships(Long id) {
        return this.findOneWithToOneRelationships(id);
    }

    default List<PackageCode> findAllWithEagerRelationships() {
        return this.findAllWithToOneRelationships();
    }

    default Page<PackageCode> findAllWithEagerRelationships(Pageable pageable) {
        return this.findAllWithToOneRelationships(pageable);
    }

    @Query(
        value = "select packageCode from PackageCode packageCode left join fetch packageCode.section",
        countQuery = "select count(packageCode) from PackageCode packageCode"
    )
    Page<PackageCode> findAllWithToOneRelationships(Pageable pageable);

    @Query("select packageCode from PackageCode packageCode left join fetch packageCode.section")
    List<PackageCode> findAllWithToOneRelationships();

    @Query("select packageCode from PackageCode packageCode left join fetch packageCode.section where packageCode.id =:id")
    Optional<PackageCode> findOneWithToOneRelationships(@Param("id") Long id);
}
