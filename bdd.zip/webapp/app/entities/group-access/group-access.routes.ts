import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import GroupAccessResolve from './route/group-access-routing-resolve.service';

const groupAccessRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/group-access.component').then(m => m.GroupAccessComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/group-access-detail.component').then(m => m.GroupAccessDetailComponent),
    resolve: {
      groupAccess: GroupAccessResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/group-access-update.component').then(m => m.GroupAccessUpdateComponent),
    resolve: {
      groupAccess: GroupAccessResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    loadComponent: () => import('./update/group-access-update.component').then(m => m.GroupAccessUpdateComponent),
    resolve: {
      groupAccess: GroupAccessResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default groupAccessRoute;
