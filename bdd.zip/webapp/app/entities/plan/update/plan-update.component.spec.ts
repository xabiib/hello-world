import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse, provideHttpClient } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subject, from, of } from 'rxjs';

import { ICostShare } from 'app/entities/cost-share/cost-share.model';
import { CostShareService } from 'app/entities/cost-share/service/cost-share.service';
import { IBenServiceList } from 'app/entities/ben-service-list/ben-service-list.model';
import { BenServiceListService } from 'app/entities/ben-service-list/service/ben-service-list.service';
import { IPlan } from '../plan.model';
import { PlanService } from '../service/plan.service';
import { PlanFormService } from './plan-form.service';

import { PlanUpdateComponent } from './plan-update.component';

describe('Plan Management Update Component', () => {
  let comp: PlanUpdateComponent;
  let fixture: ComponentFixture<PlanUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let planFormService: PlanFormService;
  let planService: PlanService;
  let costShareService: CostShareService;
  let benServiceListService: BenServiceListService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [PlanUpdateComponent],
      providers: [
        provideHttpClient(),
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(PlanUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(PlanUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    planFormService = TestBed.inject(PlanFormService);
    planService = TestBed.inject(PlanService);
    costShareService = TestBed.inject(CostShareService);
    benServiceListService = TestBed.inject(BenServiceListService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should call CostShare query and add missing value', () => {
      const plan: IPlan = { id: 456 };
      const costShare: ICostShare = { id: 28100 };
      plan.costShare = costShare;

      const costShareCollection: ICostShare[] = [{ id: 27025 }];
      jest.spyOn(costShareService, 'query').mockReturnValue(of(new HttpResponse({ body: costShareCollection })));
      const additionalCostShares = [costShare];
      const expectedCollection: ICostShare[] = [...additionalCostShares, ...costShareCollection];
      jest.spyOn(costShareService, 'addCostShareToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ plan });
      comp.ngOnInit();

      expect(costShareService.query).toHaveBeenCalled();
      expect(costShareService.addCostShareToCollectionIfMissing).toHaveBeenCalledWith(
        costShareCollection,
        ...additionalCostShares.map(expect.objectContaining),
      );
      expect(comp.costSharesSharedCollection).toEqual(expectedCollection);
    });

    it('Should call BenServiceList query and add missing value', () => {
      const plan: IPlan = { id: 456 };
      const benServiceList: IBenServiceList = { id: 10328 };
      plan.benServiceList = benServiceList;

      const benServiceListCollection: IBenServiceList[] = [{ id: 7694 }];
      jest.spyOn(benServiceListService, 'query').mockReturnValue(of(new HttpResponse({ body: benServiceListCollection })));
      const additionalBenServiceLists = [benServiceList];
      const expectedCollection: IBenServiceList[] = [...additionalBenServiceLists, ...benServiceListCollection];
      jest.spyOn(benServiceListService, 'addBenServiceListToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ plan });
      comp.ngOnInit();

      expect(benServiceListService.query).toHaveBeenCalled();
      expect(benServiceListService.addBenServiceListToCollectionIfMissing).toHaveBeenCalledWith(
        benServiceListCollection,
        ...additionalBenServiceLists.map(expect.objectContaining),
      );
      expect(comp.benServiceListsSharedCollection).toEqual(expectedCollection);
    });

    it('Should update editForm', () => {
      const plan: IPlan = { id: 456 };
      const costShare: ICostShare = { id: 446 };
      plan.costShare = costShare;
      const benServiceList: IBenServiceList = { id: 28821 };
      plan.benServiceList = benServiceList;

      activatedRoute.data = of({ plan });
      comp.ngOnInit();

      expect(comp.costSharesSharedCollection).toContain(costShare);
      expect(comp.benServiceListsSharedCollection).toContain(benServiceList);
      expect(comp.plan).toEqual(plan);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IPlan>>();
      const plan = { id: 123 };
      jest.spyOn(planFormService, 'getPlan').mockReturnValue(plan);
      jest.spyOn(planService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ plan });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: plan }));
      saveSubject.complete();

      // THEN
      expect(planFormService.getPlan).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(planService.update).toHaveBeenCalledWith(expect.objectContaining(plan));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IPlan>>();
      const plan = { id: 123 };
      jest.spyOn(planFormService, 'getPlan').mockReturnValue({ id: null });
      jest.spyOn(planService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ plan: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: plan }));
      saveSubject.complete();

      // THEN
      expect(planFormService.getPlan).toHaveBeenCalled();
      expect(planService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IPlan>>();
      const plan = { id: 123 };
      jest.spyOn(planService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ plan });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(planService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });

  describe('Compare relationships', () => {
    describe('compareCostShare', () => {
      it('Should forward to costShareService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(costShareService, 'compareCostShare');
        comp.compareCostShare(entity, entity2);
        expect(costShareService.compareCostShare).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareBenServiceList', () => {
      it('Should forward to benServiceListService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(benServiceListService, 'compareBenServiceList');
        comp.compareBenServiceList(entity, entity2);
        expect(benServiceListService.compareBenServiceList).toHaveBeenCalledWith(entity, entity2);
      });
    });
  });
});
