export interface BaseModel {
  id: number;
  createDate: string | null;
  updateDate: string | null;
}
