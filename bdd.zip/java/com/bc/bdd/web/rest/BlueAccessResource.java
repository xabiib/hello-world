package com.bc.bdd.web.rest;

import com.bc.bdd.repository.BlueAccessRepository;
import com.bc.bdd.service.BlueAccessService;
import com.bc.bdd.service.dto.BlueAccessDTO;
import com.bc.bdd.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.bc.bdd.domain.BlueAccess}.
 */
@RestController
@RequestMapping("/api/blue-accesses")
public class BlueAccessResource {

    private static final Logger LOG = LoggerFactory.getLogger(BlueAccessResource.class);

    private static final String ENTITY_NAME = "blueAccess";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final BlueAccessService blueAccessService;

    private final BlueAccessRepository blueAccessRepository;

    public BlueAccessResource(BlueAccessService blueAccessService, BlueAccessRepository blueAccessRepository) {
        this.blueAccessService = blueAccessService;
        this.blueAccessRepository = blueAccessRepository;
    }

    /**
     * {@code POST  /blue-accesses} : Create a new blueAccess.
     *
     * @param blueAccessDTO the blueAccessDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new blueAccessDTO, or with status {@code 400 (Bad Request)} if the blueAccess has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<BlueAccessDTO> createBlueAccess(@Valid @RequestBody BlueAccessDTO blueAccessDTO) throws URISyntaxException {
        LOG.debug("REST request to save BlueAccess : {}", blueAccessDTO);
        if (blueAccessDTO.getId() != null) {
            throw new BadRequestAlertException("A new blueAccess cannot already have an ID", ENTITY_NAME, "idexists");
        }
        blueAccessDTO = blueAccessService.save(blueAccessDTO);
        return ResponseEntity.created(new URI("/api/blue-accesses/" + blueAccessDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, blueAccessDTO.getId().toString()))
            .body(blueAccessDTO);
    }

    /**
     * {@code PUT  /blue-accesses/:id} : Updates an existing blueAccess.
     *
     * @param id the id of the blueAccessDTO to save.
     * @param blueAccessDTO the blueAccessDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated blueAccessDTO,
     * or with status {@code 400 (Bad Request)} if the blueAccessDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the blueAccessDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<BlueAccessDTO> updateBlueAccess(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody BlueAccessDTO blueAccessDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update BlueAccess : {}, {}", id, blueAccessDTO);
        if (blueAccessDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, blueAccessDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!blueAccessRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        blueAccessDTO = blueAccessService.update(blueAccessDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, blueAccessDTO.getId().toString()))
            .body(blueAccessDTO);
    }

    /**
     * {@code PATCH  /blue-accesses/:id} : Partial updates given fields of an existing blueAccess, field will ignore if it is null
     *
     * @param id the id of the blueAccessDTO to save.
     * @param blueAccessDTO the blueAccessDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated blueAccessDTO,
     * or with status {@code 400 (Bad Request)} if the blueAccessDTO is not valid,
     * or with status {@code 404 (Not Found)} if the blueAccessDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the blueAccessDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<BlueAccessDTO> partialUpdateBlueAccess(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody BlueAccessDTO blueAccessDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to partial update BlueAccess partially : {}, {}", id, blueAccessDTO);
        if (blueAccessDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, blueAccessDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!blueAccessRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<BlueAccessDTO> result = blueAccessService.partialUpdate(blueAccessDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, blueAccessDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /blue-accesses} : get all the blueAccesses.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of blueAccesses in body.
     */
    @GetMapping("")
    public ResponseEntity<List<BlueAccessDTO>> getAllBlueAccesses(@org.springdoc.core.annotations.ParameterObject Pageable pageable) {
        LOG.debug("REST request to get a page of BlueAccesses");
        Page<BlueAccessDTO> page = blueAccessService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /blue-accesses/:id} : get the "id" blueAccess.
     *
     * @param id the id of the blueAccessDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the blueAccessDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<BlueAccessDTO> getBlueAccess(@PathVariable("id") Long id) {
        LOG.debug("REST request to get BlueAccess : {}", id);
        Optional<BlueAccessDTO> blueAccessDTO = blueAccessService.findOne(id);
        return ResponseUtil.wrapOrNotFound(blueAccessDTO);
    }

    /**
     * {@code DELETE  /blue-accesses/:id} : delete the "id" blueAccess.
     *
     * @param id the id of the blueAccessDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBlueAccess(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete BlueAccess : {}", id);
        blueAccessService.delete(id);
        return ResponseEntity.noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
