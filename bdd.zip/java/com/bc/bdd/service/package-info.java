/**
 * Service layer.
 */
package com.bc.bdd.service;
