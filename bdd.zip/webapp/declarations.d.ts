declare const SERVER_API_URL: string;
