package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.BlueAccess} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class BlueAccessDTO implements Serializable {

    private Long id;

    @Size(max = 50)
    private String name;

    @NotNull
    @Size(max = 30)
    private String role;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BlueAccessDTO)) {
            return false;
        }

        BlueAccessDTO blueAccessDTO = (BlueAccessDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, blueAccessDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "BlueAccessDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", role='" + getRole() + "'" +
            "}";
    }
}
