package com.bc.bdd.web.rest;

import com.bc.bdd.repository.CostShareRepository;
import com.bc.bdd.service.CostShareService;
import com.bc.bdd.service.dto.CostShareDTO;
import com.bc.bdd.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.bc.bdd.domain.CostShare}.
 */
@RestController
@RequestMapping("/api/cost-shares")
public class CostShareResource {

    private static final Logger LOG = LoggerFactory.getLogger(CostShareResource.class);

    private static final String ENTITY_NAME = "costShare";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final CostShareService costShareService;

    private final CostShareRepository costShareRepository;

    public CostShareResource(CostShareService costShareService, CostShareRepository costShareRepository) {
        this.costShareService = costShareService;
        this.costShareRepository = costShareRepository;
    }

    /**
     * {@code POST  /cost-shares} : Create a new costShare.
     *
     * @param costShareDTO the costShareDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new costShareDTO, or with status {@code 400 (Bad Request)} if the costShare has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<CostShareDTO> createCostShare(@Valid @RequestBody CostShareDTO costShareDTO) throws URISyntaxException {
        LOG.debug("REST request to save CostShare : {}", costShareDTO);
        if (costShareDTO.getId() != null) {
            throw new BadRequestAlertException("A new costShare cannot already have an ID", ENTITY_NAME, "idexists");
        }
        costShareDTO = costShareService.save(costShareDTO);
        return ResponseEntity.created(new URI("/api/cost-shares/" + costShareDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, costShareDTO.getId().toString()))
            .body(costShareDTO);
    }

    /**
     * {@code PUT  /cost-shares/:id} : Updates an existing costShare.
     *
     * @param id the id of the costShareDTO to save.
     * @param costShareDTO the costShareDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated costShareDTO,
     * or with status {@code 400 (Bad Request)} if the costShareDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the costShareDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<CostShareDTO> updateCostShare(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody CostShareDTO costShareDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update CostShare : {}, {}", id, costShareDTO);
        if (costShareDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, costShareDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!costShareRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        costShareDTO = costShareService.update(costShareDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, costShareDTO.getId().toString()))
            .body(costShareDTO);
    }

    /**
     * {@code PATCH  /cost-shares/:id} : Partial updates given fields of an existing costShare, field will ignore if it is null
     *
     * @param id the id of the costShareDTO to save.
     * @param costShareDTO the costShareDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated costShareDTO,
     * or with status {@code 400 (Bad Request)} if the costShareDTO is not valid,
     * or with status {@code 404 (Not Found)} if the costShareDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the costShareDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<CostShareDTO> partialUpdateCostShare(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody CostShareDTO costShareDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to partial update CostShare partially : {}, {}", id, costShareDTO);
        if (costShareDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, costShareDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!costShareRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<CostShareDTO> result = costShareService.partialUpdate(costShareDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, costShareDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /cost-shares} : get all the costShares.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of costShares in body.
     */
    @GetMapping("")
    public ResponseEntity<List<CostShareDTO>> getAllCostShares(@org.springdoc.core.annotations.ParameterObject Pageable pageable) {
        LOG.debug("REST request to get a page of CostShares");
        Page<CostShareDTO> page = costShareService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /cost-shares/:id} : get the "id" costShare.
     *
     * @param id the id of the costShareDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the costShareDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<CostShareDTO> getCostShare(@PathVariable("id") Long id) {
        LOG.debug("REST request to get CostShare : {}", id);
        Optional<CostShareDTO> costShareDTO = costShareService.findOne(id);
        return ResponseUtil.wrapOrNotFound(costShareDTO);
    }

    /**
     * {@code DELETE  /cost-shares/:id} : delete the "id" costShare.
     *
     * @param id the id of the costShareDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCostShare(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete CostShare : {}", id);
        costShareService.delete(id);
        return ResponseEntity.noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
