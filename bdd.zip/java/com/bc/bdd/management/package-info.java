/**
 * Application management.
 */
package com.bc.bdd.management;
