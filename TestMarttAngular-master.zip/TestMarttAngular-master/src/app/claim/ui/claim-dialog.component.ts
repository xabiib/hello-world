import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Inject,
  Output,
} from "@angular/core";
import {
  FormControl,
 // FormGroup,
  ReactiveFormsModule,
//  Validators,
} from "@angular/forms";
import { MatButtonModule } from "@angular/material/button";
import {
  MAT_DIALOG_DATA,
  MatDialogModule,
  MatDialogRef,
} from "@angular/material/dialog";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";
import { Claim } from "../claim.model";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { provideNativeDateAdapter } from "@angular/material/core";
import { getDateWithoutTimezone } from "../../utils/date-utils";
import { Observable, Subject, map, tap } from "rxjs";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { AsyncPipe } from "@angular/common";
//import { ProductWithStock } from "../../products/product-with-stock.model";
import { MatDividerModule } from '@angular/material/divider'; 
import {MatCardModule }     from '@angular/material/card' ;
import {MatStepperModule }  from '@angular/material/stepper' 
import { FormBuilder,Validators,FormGroup } from "@angular/forms"
import {STEPPER_GLOBAL_OPTIONS} from '@angular/cdk/stepper';
import { Project } from "../../projects/project.model";


@Component({
  selector: "app-claim-dialog",
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDialogModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    AsyncPipe, MatDividerModule, MatCardModule , MatStepperModule,
  ],
  providers: [  {
    provide: STEPPER_GLOBAL_OPTIONS,
    useValue: {showError: true},
  },provideNativeDateAdapter()],
  templateUrl: './claim-dialog-component.html',
  styleUrls: ['./claim-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClaimDialogComponent {
  @Output() sumbit = new EventEmitter<Claim>();
  //filteredProducts$!: Observable<ProductWithStock[]> | undefined;
  isLinear=true;
  selectedOption = 0 ;

  ngOnInit(): void {
  }


/*   claimForm: FormGroup = new FormGroup({
    id: new FormControl<number>(0),
    descriptiontext: new FormControl<string | null>("", Validators.required),
    private: new FormControl<string>('', Validators.required),
 //   productId: new FormControl<number | null>(null, Validators.required),
    providernum: new FormControl<string>('', Validators.required),
    payee: new FormControl<string>('', Validators.required),
    luClaimClass: new FormControl<string>(""),
    accidentind: new FormControl<string | null>("", Validators.required),
    conditiondate: new FormControl<string>('', Validators.required),
    refprovidernum: new FormControl<string>('', Validators.required),
  }); */

/*   displayFn(productId: number | null) {
    if (!productId || !this.data.products) return "";

    const product = this.data.products.find((a) => a.id === productId);

    if (!product) return "";
    this._setPrice(product.price);
    this._setTotalPrice();
    return product.productName;
  }

  private _setPrice(price: number) {
   // this.claimForm.get("price")?.setValue(price);
  } */

  private _setTotalPrice() {
  /*   const quantity: number | null = this.claimForm.get("quantity")?.value;
    const price: number | null = this.claimForm.get("price")?.value;
    if (price && quantity) {
      const totalPrice = price * quantity;
      this.claimForm.get("totalPrice")?.setValue(totalPrice);
    } */
  }

  onCanceled() {
    this.dialogRef.close();
  }

  onSubmit() {
    if (this.claimForm.valid) {
         console.log(this.claimForm.get("descriptiontext")?.value);
      const claim: Claim = Object.assign(
        this.claimForm.value
      ) as Claim;
      const conditiondate = getDateWithoutTimezone(
        new Date(claim.conditiondate? claim.conditiondate : "01/23/2025") 
      );
      this.sumbit.emit({ ...claim, conditiondate });
    }
  }

  constructor( private builder: FormBuilder ,
    public dialogRef: MatDialogRef<ClaimDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      title: string;
      claim: Claim | null;
      products: Project[];
    }
  ) {
    if (data.claim) {
      this.selectedOption = data.claim.id  ; //revisit this after discuss with the team.
    //  this.claimForm.patchValue(data.claim);
    //  this._setTotalPrice();
    }
    // on value changes of productId
 /*    this.filteredProducts$ = this.claimForm
      .get<string>("productId")
      ?.valueChanges.pipe(
        map((value) => {
          if (!value || typeof value !== "string") return [];
          const searchTerm = value ? value.toLocaleLowerCase() : "";
          const filteredProducts = this.data.products.filter((a) =>
            a.productName?.toLowerCase().includes(searchTerm)
          );
          return filteredProducts;
        })
      ); */
  }

  /////////////////////////

  claimForm = this.builder.group({
    header: this.builder.group({
      id:this.builder.control(0,Validators.required),
      descriptiontext:this.builder.control('',Validators.required),
      luClaimClass:this.builder.control('',Validators.required),
      privateind:this.builder.control('',Validators.required),
      accidentind:this.builder.control('',Validators.required),
      providernum:this.builder.control('',Validators.required),
      refprovidernum:this.builder.control('',Validators.required),
      conditiondate:this.builder.control('',Validators.required),
      payee:this.builder.control('',Validators.required), 

    }),
   /*  provider: this.builder.group({
        providernum:this.builder.control('',Validators.required),
        refprovidernum:this.builder.control('',Validators.required),
        conditiondate:this.builder.control('',Validators.required),
        payee:this.builder.control('',Validators.required),

    }), */
    procedure: this.builder.group({
        proc01:this.builder.control('',Validators.required),
        proc02:this.builder.control('',Validators.required),
       proc03:this.builder.control('',Validators.required),
        proc04:this.builder.control('',Validators.required),
        proc05:this.builder.control('',Validators.required),
        proc06:this.builder.control('',Validators.required),
        proc07:this.builder.control('',Validators.required),
        proc08:this.builder.control('',Validators.required),
        proc09:this.builder.control('',Validators.required) 
    }),
    diagnosis: this.builder.group({
        diag01:this.builder.control('',Validators.required),
        diag02:this.builder.control('',Validators.required),
        diag03:this.builder.control('',Validators.required),
        diag04:this.builder.control('',Validators.required),
        diag05:this.builder.control('',Validators.required),
        diag06:this.builder.control('',Validators.required),
        diag07:this.builder.control('',Validators.required),
        diag08:this.builder.control('',Validators.required),
        diag09:this.builder.control('',Validators.required) 
    }),
  });

  get headerform(){
   // console.error('@@@@@@@@@@ ---->>>' + this.claimForm.get("header")) ;
    return this.claimForm.get("header") as FormGroup;
  }
/*   get providerform(){
    return this.claimShell.get("provider") as FormGroup;
  } */
  get procedureform(){
    return this.claimForm.get("procedure") as FormGroup;
  }
  get diagnosisform(){
    return this.claimForm.get("diagnosis") as FormGroup;
  }
  
  handleSubmit(){
    console.log("Begore ********  "+ this.claimForm.get("descriptiontext")?.value);
    if(this.claimForm.valid){
      console.log(this.claimForm.value);
    }
  }
}
