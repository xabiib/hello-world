import { Injectable, inject } from "@angular/core";
import { environment } from "../../environments/environment.development";
import { PaginatedProject, Project as Project } from "./project.model";
import { Observable, map } from "rxjs";
import { HttpClient, HttpParams } from "@angular/common/http";
import { PaginationModel } from "../shared/models/pagination.model";

@Injectable({
  providedIn: "root",
})
export class ProjectService {
  #http = inject(HttpClient);
 // #baseUrl = environment.API_BASE_URL + "/projects";

 #baseUrl =  'assets/project.json';

  addProject(project: Project): Observable<Project> {
    return this.#http.post<Project>(this.#baseUrl, project);
  }

  updateProject(project: Project): Observable<Project> {
    const url = `${this.#baseUrl}/${project.claimScenarioId}`;
    return this.#http.put<Project>(url, project);
  }

  deleteProject(id: number): Observable<any> {
    const url = `${this.#baseUrl}/${id}`;
    return this.#http.delete<any>(url);
  }

  getProject(id: number): Observable<Project> {
    const url = `${this.#baseUrl}/${id}`;
    return this.#http.get<Project>(url);
  }

  getProjects(
    //page = 1,  limit = 4,
   // searchTerm: string | null = null, userid: string | null = null,
    projectForm: any
   // sortColumn: string | null = null,    sortDirection: string | null = null
  ): Observable<PaginatedProject> {
    let parameters = new HttpParams();
   // parameters = parameters.set("page", page);
  //  parameters = parameters.set("limit", limit);
    if (projectForm.descriptionText) parameters = parameters.set("searchTerm", projectForm.descriptionText);
    if (projectForm.userId) parameters = parameters.set("userid", projectForm.userId);
    
    return this.#http
      .get(this.#baseUrl, {
        observe: "response",
        params: parameters,
      })
      .pipe(
        map((response) => {
          const paginationHeader = response.headers.get(
            "X-Pagination"
          ) as string;
          const paginationData: PaginationModel = JSON.parse(paginationHeader);
          let projects = response.body as Project[];
          // this is testing only
          console.log("@@-Start  : " + projects.length);
          if (projectForm.descriptionText) {
            console.log("@@--@@ " + projectForm.descriptionText);
             projects = projects.filter((prod) => prod.descriptionText?.includes(projectForm.descriptionText));
             console.log("@@-Tiele-@@ After : " + projects.length);
          } else if (projectForm.userId) {
            console.log("@@-UsrrID-@@ " + projectForm.userId);
            projects = projects.filter((prod) => prod.userId?.includes(projectForm.userId));
            console.log("@@-UsrrID-@@ After : " + projects.length);
          }
          const ProjectResponse: PaginatedProject = {
            ...paginationData,
            projects,
          };
          return ProjectResponse;
        })
      );
  }

  getAllProjects(): Observable<any> {
    return this.#http.get( this.#baseUrl);
  }

 /*  getAllProjectsWithClaim(): Observable<ProjectWithClaim[]> {
    return this.#http.get<ProjectWithClaim[]>( 'assets/pstock.json'
      //this.#baseUrl + "/all-projecs-with-claim"
    );
  } */

  searchProjects(projectForm: any  ): Observable<Project []> {
    let parameters = new HttpParams();

    if (projectForm.descriptionText) parameters = parameters.set("searchTerm", projectForm.descriptionText);
    if (projectForm.userId) parameters = parameters.set("userid", projectForm.userId);
    
    return this.#http
      .get(this.#baseUrl, {
        observe: "response",
        params: parameters,
      })
      .pipe(
        map((response) => {
          const paginationHeader = response.headers.get(
            "X-Pagination"
          ) as string;
          let projects = response.body as Project[];
          // this is testing only
         if (projectForm.descriptionText) {
             projects = projects.filter((prod) => prod.descriptionText?.includes(projectForm.descriptionText));
          } else if (projectForm.userId) {
            projects = projects.filter((prod) => prod.userId?.includes(projectForm.userId));
          }
          
          return projects;
        })
      );
  }
}
