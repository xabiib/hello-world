# TestMart Angular

Porting Test Mart functionality from .Net to  angular and Spring boot core apis.

## Development server

Run `ng serve --open`

## Tech Stack

- Angular 17
- Angular material
- Ngrx componnent store
- Spring Boot for the backend ???

## Backend url

Backend of this project made with Spring Boot 3.2.
