export interface PaginationModel {
  Page: number;
  Limit: number;
  TotalPages: number;
  TotalRecords: number;
}
