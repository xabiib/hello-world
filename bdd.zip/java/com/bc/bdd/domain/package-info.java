/**
 * Domain objects.
 */
package com.bc.bdd.domain;
