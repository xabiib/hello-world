import { Component, OnInit, inject } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs';
import { finalize, map } from 'rxjs/operators';

import SharedModule from 'app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IPackageCode } from 'app/entities/package-code/package-code.model';
import { PackageCodeService } from 'app/entities/package-code/service/package-code.service';
import { IUser } from 'app/entities/user/user.model';
import { UserService } from 'app/entities/user/service/user.service';
import { IPlan } from 'app/entities/plan/plan.model';
import { PlanService } from 'app/entities/plan/service/plan.service';
import { PackagePlanService } from '../service/package-plan.service';
import { IPackagePlan } from '../package-plan.model';
import { PackagePlanFormGroup, PackagePlanFormService } from './package-plan-form.service';

@Component({
  standalone: true,
  selector: 'jhi-package-plan-update',
  templateUrl: './package-plan-update.component.html',
  imports: [SharedModule, FormsModule, ReactiveFormsModule],
})
export class PackagePlanUpdateComponent implements OnInit {
  isSaving = false;
  packagePlan: IPackagePlan | null = null;

  packageCodesSharedCollection: IPackageCode[] = [];
  usersSharedCollection: IUser[] = [];
  plansSharedCollection: IPlan[] = [];

  protected packagePlanService = inject(PackagePlanService);
  protected packagePlanFormService = inject(PackagePlanFormService);
  protected packageCodeService = inject(PackageCodeService);
  protected userService = inject(UserService);
  protected planService = inject(PlanService);
  protected activatedRoute = inject(ActivatedRoute);

  // eslint-disable-next-line @typescript-eslint/member-ordering
  editForm: PackagePlanFormGroup = this.packagePlanFormService.createPackagePlanFormGroup();

  comparePackageCode = (o1: IPackageCode | null, o2: IPackageCode | null): boolean => this.packageCodeService.comparePackageCode(o1, o2);

  compareUser = (o1: IUser | null, o2: IUser | null): boolean => this.userService.compareUser(o1, o2);

  comparePlan = (o1: IPlan | null, o2: IPlan | null): boolean => this.planService.comparePlan(o1, o2);

  ngOnInit(): void {
    this.activatedRoute.data.subscribe(({ packagePlan }) => {
      this.packagePlan = packagePlan;
      if (packagePlan) {
        this.updateForm(packagePlan);
      }

      this.loadRelationshipsOptions();
    });
  }

  previousState(): void {
    window.history.back();
  }

  save(): void {
    this.isSaving = true;
    const packagePlan = this.packagePlanFormService.getPackagePlan(this.editForm);
    if (packagePlan.id !== null) {
      this.subscribeToSaveResponse(this.packagePlanService.update(packagePlan));
    } else {
      this.subscribeToSaveResponse(this.packagePlanService.create(packagePlan));
    }
  }

  protected subscribeToSaveResponse(result: Observable<HttpResponse<IPackagePlan>>): void {
    result.pipe(finalize(() => this.onSaveFinalize())).subscribe({
      next: () => this.onSaveSuccess(),
      error: () => this.onSaveError(),
    });
  }

  protected onSaveSuccess(): void {
    this.previousState();
  }

  protected onSaveError(): void {
    // Api for inheritance.
  }

  protected onSaveFinalize(): void {
    this.isSaving = false;
  }

  protected updateForm(packagePlan: IPackagePlan): void {
    this.packagePlan = packagePlan;
    this.packagePlanFormService.resetForm(this.editForm, packagePlan);

    this.packageCodesSharedCollection = this.packageCodeService.addPackageCodeToCollectionIfMissing<IPackageCode>(
      this.packageCodesSharedCollection,
      packagePlan.packagecode,
    );
    this.usersSharedCollection = this.userService.addUserToCollectionIfMissing<IUser>(this.usersSharedCollection, packagePlan.user);
    this.plansSharedCollection = this.planService.addPlanToCollectionIfMissing<IPlan>(this.plansSharedCollection, packagePlan.plan);
  }

  protected loadRelationshipsOptions(): void {
    this.packageCodeService
      .query()
      .pipe(map((res: HttpResponse<IPackageCode[]>) => res.body ?? []))
      .pipe(
        map((packageCodes: IPackageCode[]) =>
          this.packageCodeService.addPackageCodeToCollectionIfMissing<IPackageCode>(packageCodes, this.packagePlan?.packagecode),
        ),
      )
      .subscribe((packageCodes: IPackageCode[]) => (this.packageCodesSharedCollection = packageCodes));

    this.userService
      .query()
      .pipe(map((res: HttpResponse<IUser[]>) => res.body ?? []))
      .pipe(map((users: IUser[]) => this.userService.addUserToCollectionIfMissing<IUser>(users, this.packagePlan?.user)))
      .subscribe((users: IUser[]) => (this.usersSharedCollection = users));

    this.planService
      .query()
      .pipe(map((res: HttpResponse<IPlan[]>) => res.body ?? []))
      .pipe(map((plans: IPlan[]) => this.planService.addPlanToCollectionIfMissing<IPlan>(plans, this.packagePlan?.plan)))
      .subscribe((plans: IPlan[]) => (this.plansSharedCollection = plans));
  }
}
