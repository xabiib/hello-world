package com.bc.bdd.service.impl;

import com.bc.bdd.domain.CostShare;
import com.bc.bdd.repository.CostShareRepository;
import com.bc.bdd.service.CostShareService;
import com.bc.bdd.service.dto.CostShareDTO;
import com.bc.bdd.service.mapper.CostShareMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.CostShare}.
 */
@Service
@Transactional
public class CostShareServiceImpl implements CostShareService {

    private static final Logger LOG = LoggerFactory.getLogger(CostShareServiceImpl.class);

    private final CostShareRepository costShareRepository;

    private final CostShareMapper costShareMapper;

    public CostShareServiceImpl(CostShareRepository costShareRepository, CostShareMapper costShareMapper) {
        this.costShareRepository = costShareRepository;
        this.costShareMapper = costShareMapper;
    }

    @Override
    public CostShareDTO save(CostShareDTO costShareDTO) {
        LOG.debug("Request to save CostShare : {}", costShareDTO);
        CostShare costShare = costShareMapper.toEntity(costShareDTO);
        costShare = costShareRepository.save(costShare);
        return costShareMapper.toDto(costShare);
    }

    @Override
    public CostShareDTO update(CostShareDTO costShareDTO) {
        LOG.debug("Request to update CostShare : {}", costShareDTO);
        CostShare costShare = costShareMapper.toEntity(costShareDTO);
        costShare = costShareRepository.save(costShare);
        return costShareMapper.toDto(costShare);
    }

    @Override
    public Optional<CostShareDTO> partialUpdate(CostShareDTO costShareDTO) {
        LOG.debug("Request to partially update CostShare : {}", costShareDTO);

        return costShareRepository
            .findById(costShareDTO.getId())
            .map(existingCostShare -> {
                costShareMapper.partialUpdate(existingCostShare, costShareDTO);

                return existingCostShare;
            })
            .map(costShareRepository::save)
            .map(costShareMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<CostShareDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all CostShares");
        return costShareRepository.findAll(pageable).map(costShareMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<CostShareDTO> findOne(Long id) {
        LOG.debug("Request to get CostShare : {}", id);
        return costShareRepository.findById(id).map(costShareMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete CostShare : {}", id);
        costShareRepository.deleteById(id);
    }
}
