package com.bc.bdd.service;

import com.bc.bdd.service.dto.BlueAccessDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.BlueAccess}.
 */
public interface BlueAccessService {
    /**
     * Save a blueAccess.
     *
     * @param blueAccessDTO the entity to save.
     * @return the persisted entity.
     */
    BlueAccessDTO save(BlueAccessDTO blueAccessDTO);

    /**
     * Updates a blueAccess.
     *
     * @param blueAccessDTO the entity to update.
     * @return the persisted entity.
     */
    BlueAccessDTO update(BlueAccessDTO blueAccessDTO);

    /**
     * Partially updates a blueAccess.
     *
     * @param blueAccessDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<BlueAccessDTO> partialUpdate(BlueAccessDTO blueAccessDTO);

    /**
     * Get all the blueAccesses.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<BlueAccessDTO> findAll(Pageable pageable);

    /**
     * Get the "id" blueAccess.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<BlueAccessDTO> findOne(Long id);

    /**
     * Delete the "id" blueAccess.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
