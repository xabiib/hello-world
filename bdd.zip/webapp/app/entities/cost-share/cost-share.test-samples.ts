import { ICostShare, NewCostShare } from './cost-share.model';

export const sampleWithRequiredData: ICostShare = {
  id: 19453,
};

export const sampleWithPartialData: ICostShare = {
  id: 19546,
  period: 'sedately a',
  dedOutN: 8642,
  dedFamily: 24233,
  priorDed: true,
  commonAccient: false,
  oopINN: 4789,
  oopFamily: 6596,
  dedContributeToOpp: true,
  lifeTime: 5732,
};

export const sampleWithFullData: ICostShare = {
  id: 4389,
  period: 'and miserl',
  csAcculation: 'roughen',
  csProcess: 'laundry minus',
  dedINN: 22853,
  dedOutN: 18565,
  dedFamily: 29268,
  fourthQuarter: 'minor',
  priorDed: false,
  commonAccient: true,
  oopINN: 31506,
  oopOutN: 1845,
  oopFamily: 5912,
  dedContributeToOpp: true,
  lifeTime: 30318,
};

export const sampleWithNewData: NewCostShare = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
