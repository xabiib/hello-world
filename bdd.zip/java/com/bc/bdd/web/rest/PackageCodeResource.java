package com.bc.bdd.web.rest;

import com.bc.bdd.repository.PackageCodeRepository;
import com.bc.bdd.service.PackageCodeService;
import com.bc.bdd.service.dto.PackageCodeDTO;
import com.bc.bdd.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.bc.bdd.domain.PackageCode}.
 */
@RestController
@RequestMapping("/api/package-codes")
public class PackageCodeResource {

    private static final Logger LOG = LoggerFactory.getLogger(PackageCodeResource.class);

    private static final String ENTITY_NAME = "packageCode";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final PackageCodeService packageCodeService;

    private final PackageCodeRepository packageCodeRepository;

    public PackageCodeResource(PackageCodeService packageCodeService, PackageCodeRepository packageCodeRepository) {
        this.packageCodeService = packageCodeService;
        this.packageCodeRepository = packageCodeRepository;
    }

    /**
     * {@code POST  /package-codes} : Create a new packageCode.
     *
     * @param packageCodeDTO the packageCodeDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new packageCodeDTO, or with status {@code 400 (Bad Request)} if the packageCode has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<PackageCodeDTO> createPackageCode(@Valid @RequestBody PackageCodeDTO packageCodeDTO) throws URISyntaxException {
        LOG.debug("REST request to save PackageCode : {}", packageCodeDTO);
        if (packageCodeDTO.getId() != null) {
            throw new BadRequestAlertException("A new packageCode cannot already have an ID", ENTITY_NAME, "idexists");
        }
        packageCodeDTO = packageCodeService.save(packageCodeDTO);
        return ResponseEntity.created(new URI("/api/package-codes/" + packageCodeDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, packageCodeDTO.getId().toString()))
            .body(packageCodeDTO);
    }

    /**
     * {@code PUT  /package-codes/:id} : Updates an existing packageCode.
     *
     * @param id the id of the packageCodeDTO to save.
     * @param packageCodeDTO the packageCodeDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated packageCodeDTO,
     * or with status {@code 400 (Bad Request)} if the packageCodeDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the packageCodeDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<PackageCodeDTO> updatePackageCode(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody PackageCodeDTO packageCodeDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to update PackageCode : {}, {}", id, packageCodeDTO);
        if (packageCodeDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, packageCodeDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!packageCodeRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        packageCodeDTO = packageCodeService.update(packageCodeDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, packageCodeDTO.getId().toString()))
            .body(packageCodeDTO);
    }

    /**
     * {@code PATCH  /package-codes/:id} : Partial updates given fields of an existing packageCode, field will ignore if it is null
     *
     * @param id the id of the packageCodeDTO to save.
     * @param packageCodeDTO the packageCodeDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated packageCodeDTO,
     * or with status {@code 400 (Bad Request)} if the packageCodeDTO is not valid,
     * or with status {@code 404 (Not Found)} if the packageCodeDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the packageCodeDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<PackageCodeDTO> partialUpdatePackageCode(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody PackageCodeDTO packageCodeDTO
    ) throws URISyntaxException {
        LOG.debug("REST request to partial update PackageCode partially : {}, {}", id, packageCodeDTO);
        if (packageCodeDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, packageCodeDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!packageCodeRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<PackageCodeDTO> result = packageCodeService.partialUpdate(packageCodeDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, false, ENTITY_NAME, packageCodeDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /package-codes} : get all the packageCodes.
     *
     * @param pageable the pagination information.
     * @param eagerload flag to eager load entities from relationships (This is applicable for many-to-many).
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of packageCodes in body.
     */
    @GetMapping("")
    public ResponseEntity<List<PackageCodeDTO>> getAllPackageCodes(
        @org.springdoc.core.annotations.ParameterObject Pageable pageable,
        @RequestParam(name = "eagerload", required = false, defaultValue = "true") boolean eagerload
    ) {
        LOG.debug("REST request to get a page of PackageCodes");
        Page<PackageCodeDTO> page;
        if (eagerload) {
            page = packageCodeService.findAllWithEagerRelationships(pageable);
        } else {
            page = packageCodeService.findAll(pageable);
        }
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /package-codes/:id} : get the "id" packageCode.
     *
     * @param id the id of the packageCodeDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the packageCodeDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<PackageCodeDTO> getPackageCode(@PathVariable("id") Long id) {
        LOG.debug("REST request to get PackageCode : {}", id);
        Optional<PackageCodeDTO> packageCodeDTO = packageCodeService.findOne(id);
        return ResponseUtil.wrapOrNotFound(packageCodeDTO);
    }

    /**
     * {@code DELETE  /package-codes/:id} : delete the "id" packageCode.
     *
     * @param id the id of the packageCodeDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePackageCode(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete PackageCode : {}", id);
        packageCodeService.delete(id);
        return ResponseEntity.noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
