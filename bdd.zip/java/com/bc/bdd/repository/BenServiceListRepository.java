package com.bc.bdd.repository;

import com.bc.bdd.domain.BenServiceList;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the BenServiceList entity.
 */
@SuppressWarnings("unused")
@Repository
public interface BenServiceListRepository extends JpaRepository<BenServiceList, Long> {}
