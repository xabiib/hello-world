/**
 * Rest layer visual models.
 */
package com.bc.bdd.web.rest.vm;
