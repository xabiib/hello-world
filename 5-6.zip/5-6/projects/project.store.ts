import { Injectable, inject } from "@angular/core";
import {
  ComponentStore,
  OnStateInit,
  OnStoreInit,
  tapResponse,
} from "@ngrx/component-store";
import { PaginatedProject, Project as Project } from "./project.model";
import { HttpErrorResponse } from "@angular/common/http";
import { combineLatest, exhaustMap, switchMap, tap } from "rxjs";
import { ProjectService } from "./project.service";

interface ProjectState {
  projects: Project[];
 // searchTerm: string | null;
 // userid:     string | null ;
  projectForm: ProjectForm ;
  loading: boolean;
  error: HttpErrorResponse | null;
}

const initialState: ProjectState = {
  projects: [],
  projectForm : {} as ProjectForm,
 // searchTerm: null,
 // userid: null ,
//  sortColumn: null,
 // sortDirection: null,
 // page: 1,
 // limit: 4,
//  totalRecords: 0,
  loading: false,
  error: null,
};

interface ProjectForm {
  descriptionText: string | null, 
  userId: string | null; 
}

@Injectable()
export class ProjectStore
  extends ComponentStore<ProjectState>
  implements OnStoreInit, OnStateInit
{
  private readonly projectService = inject(ProjectService);

  private readonly projects$ = this.select((a) => a.projects);
  private readonly loading$ = this.select((a) => a.loading);
  private readonly error$ = this.select((a) => a.error);
 // private readonly page$ = this.select((a) => a.page);
 // private readonly limit$ = this.select((a) => a.limit);
 // private readonly totalRecords$ = this.select((a) => a.totalRecords);
  private readonly projectForm$ = this.select((a) => a.projectForm);
  //private readonly userid$ = this.select((a) => a.userid);
 // private readonly sortColumn$ = this.select((a) => a.sortColumn);
 // private readonly sortDirection$ = this.select((a) => a.sortDirection);

  readonly vm$ = this.select({
    projects: this.projects$,
    //searchTerm: this.searchTerm$,
    projectForm: this.projectForm$,
   // sortColumn: this.sortColumn$,
    ///sortDirection: this.sortDirection$,
   // page: this.page$,
   // limit: this.limit$,
   // totalRecords: this.totalRecords$,
    loading: this.loading$,
    error: this.error$,
  });

  constructor() {
    super(initialState);
  }

  private readonly addMultipleProjectToStore = this.updater(
    (state, projects: Project[]) => ({
      ...state,
      loading: false,
      projects,
    })
  );

  private readonly addSingleProjectToStore = this.updater(function updaterFn(
    state,
    project: Project
  ) {
    const updateState = {
      ...state,
      loading: false,
      projects: [...state.projects, project],
    };
    return updateState;
  });

  private readonly updateStoresProject = this.updater(
    (state, project: Project) => ({
      ...state,
      loading: false,
      projects: state.projects.map((p) => (p.claimScenarioId === project.claimScenarioId ? project : p)),
    })
  );

  private readonly deleteStoresProject = this.updater((state, id: number) => ({
    ...state,
    loading: false,
    projects: state.projects.filter((p) => p.claimScenarioId !== id),
  }));

  private readonly setLoading = this.updater((state) => ({
    ...state,
    loading: true,
  }));

  private readonly setError = this.updater(
    (state, error: HttpErrorResponse) => ({
      ...state,
      error,
      loading: false,
    })
  );

  readonly setProjectForm = this.updater((state, projectForm: ProjectForm) => ({
    ...state,
   // projects: [...state.projects] ,
    projects: state.projects.filter((p) => p.userId?.trim().toLocaleLowerCase() === projectForm.userId?.trim().toLowerCase() ),
 //   projectForm,
  }));

  /* readonly setUserid = this.updater((state, userid: string | null) => ({
    ...state,
    userid,
  })); */

 /*  readonly setSortColumn = this.updater((state, sortColumn: string | null) => ({
    ...state,
    sortColumn,
  }));

  readonly setSortDirection = this.updater(
    (state, sortDirection: "asc" | "desc" | null) => ({
      ...state,
      sortDirection,
    })
  );

  readonly setPage = this.updater((state, page: number) => ({
    ...state,
    page,
  }));

  readonly setPageLimit = this.updater((state, limit: number) => ({
    ...state,
    limit,
  }));

  readonly setTotalRecords = this.updater((state, totalRecords: number) => ({
    ...state,
    totalRecords,
  }));
 */
  readonly addProject = this.effect<Project>((project$) =>
    project$.pipe(
      tap(this.setLoading),
      switchMap((project) =>
        this.projectService.addProject(project).pipe(
          tapResponse(
            (response) => this.addSingleProjectToStore(response),
            (error: HttpErrorResponse) => this.setError(error)
          )
        )
      )
    )
  );

  readonly updateProject = this.effect<Project>((project$) =>
    project$.pipe(
      tap(this.setLoading),
      switchMap((project) =>
        this.projectService.updateProject(project).pipe(
          tapResponse(
            (response) => this.updateStoresProject(response),
            (error: HttpErrorResponse) => this.setError(error)
          )
        )
      )
    )
  );
  readonly deleteProject = this.effect<number>((project$) =>
    project$.pipe(
      tap(this.setLoading),
      switchMap((id) =>
        this.projectService.deleteProject(id).pipe(
          tapResponse(
            () => this.deleteStoresProject(id),
            (error: HttpErrorResponse) => this.setError(error)
          )
        )
      )
    )
  );

  readonly loadProjects = this.effect<void>((trigger$) =>
    trigger$.pipe(
      tap(() => this.setLoading()),
      exhaustMap(() => {
        const combinedStream$ = combineLatest([
          this.projectForm$        ]);
        console.log('@@@@@@ EFFECT - produc store @@@@@@ ' ) ;
        return combinedStream$.pipe(
          switchMap(([projectForm]) =>
            this.projectService
              .getProjects(projectForm)
              .pipe(
                tapResponse(
                  (response) => {
                    this.loadProjectResponse(response);
                  },
                  (error: HttpErrorResponse) => this.setError(error)
                )
              )
          )
        );
        // return this.productService.getProducts().pipe(
        //   tapResponse(
        //     (response) => this.loadProductResponse(response),
        //     (error: HttpErrorResponse) => this.setError(error)
        //   )
        // );
      })
    )
  );

  ngrxOnStateInit() {
    console.log('@@@@@@ngrxOnStateInit - produc store @@@@@@ ' + this.projectForm$) ;
    this.loadProjects();
  }
  ngrxOnStoreInit() {}

  private loadProjectResponse = (response: PaginatedProject) => {
     console.log({
       products: response.projects,
       count: response.projects.length,
     });
    
    this.addMultipleProjectToStore(response.projects);
    /* this.setPage(response.Page);
    this.setPageLimit(response.Limit);
    this.setTotalRecords(response.TotalRecords); */
  };
}
