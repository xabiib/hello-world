/**
 * Data transfer objects for rest mapping.
 */
package com.bc.bdd.service.dto;
