package com.bc.bdd.service.impl;

import com.bc.bdd.domain.PackagePlan;
import com.bc.bdd.repository.PackagePlanRepository;
import com.bc.bdd.service.PackagePlanService;
import com.bc.bdd.service.dto.PackagePlanDTO;
import com.bc.bdd.service.mapper.PackagePlanMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.PackagePlan}.
 */
@Service
@Transactional
public class PackagePlanServiceImpl implements PackagePlanService {

    private static final Logger LOG = LoggerFactory.getLogger(PackagePlanServiceImpl.class);

    private final PackagePlanRepository packagePlanRepository;

    private final PackagePlanMapper packagePlanMapper;

    public PackagePlanServiceImpl(PackagePlanRepository packagePlanRepository, PackagePlanMapper packagePlanMapper) {
        this.packagePlanRepository = packagePlanRepository;
        this.packagePlanMapper = packagePlanMapper;
    }

    @Override
    public PackagePlanDTO save(PackagePlanDTO packagePlanDTO) {
        LOG.debug("Request to save PackagePlan : {}", packagePlanDTO);
        PackagePlan packagePlan = packagePlanMapper.toEntity(packagePlanDTO);
        packagePlan = packagePlanRepository.save(packagePlan);
        return packagePlanMapper.toDto(packagePlan);
    }

    @Override
    public PackagePlanDTO update(PackagePlanDTO packagePlanDTO) {
        LOG.debug("Request to update PackagePlan : {}", packagePlanDTO);
        PackagePlan packagePlan = packagePlanMapper.toEntity(packagePlanDTO);
        packagePlan = packagePlanRepository.save(packagePlan);
        return packagePlanMapper.toDto(packagePlan);
    }

    @Override
    public Optional<PackagePlanDTO> partialUpdate(PackagePlanDTO packagePlanDTO) {
        LOG.debug("Request to partially update PackagePlan : {}", packagePlanDTO);

        return packagePlanRepository
            .findById(packagePlanDTO.getId())
            .map(existingPackagePlan -> {
                packagePlanMapper.partialUpdate(existingPackagePlan, packagePlanDTO);

                return existingPackagePlan;
            })
            .map(packagePlanRepository::save)
            .map(packagePlanMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PackagePlanDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all PackagePlans");
        return packagePlanRepository.findAll(pageable).map(packagePlanMapper::toDto);
    }

    public Page<PackagePlanDTO> findAllWithEagerRelationships(Pageable pageable) {
        return packagePlanRepository.findAllWithEagerRelationships(pageable).map(packagePlanMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PackagePlanDTO> findOne(Long id) {
        LOG.debug("Request to get PackagePlan : {}", id);
        return packagePlanRepository.findOneWithEagerRelationships(id).map(packagePlanMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete PackagePlan : {}", id);
        packagePlanRepository.deleteById(id);
    }
}
