import { IBenServiceList, NewBenServiceList } from './ben-service-list.model';

export const sampleWithRequiredData: IBenServiceList = {
  id: 24385,
};

export const sampleWithPartialData: IBenServiceList = {
  id: 22673,
};

export const sampleWithFullData: IBenServiceList = {
  id: 13069,
};

export const sampleWithNewData: NewBenServiceList = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
