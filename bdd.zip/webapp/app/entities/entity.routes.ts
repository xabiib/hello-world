import { Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'authority',
    data: { pageTitle: 'Authorities' },
    loadChildren: () => import('./admin/authority/authority.routes'),
  },
  {
    path: 'group',
    data: { pageTitle: 'Groups' },
    loadChildren: () => import('./group/group.routes'),
  },
  {
    path: 'section',
    data: { pageTitle: 'Sections' },
    loadChildren: () => import('./section/section.routes'),
  },
  {
    path: 'package-code',
    data: { pageTitle: 'PackageCodes' },
    loadChildren: () => import('./package-code/package-code.routes'),
  },
  {
    path: 'package-plan',
    data: { pageTitle: 'PackagePlans' },
    loadChildren: () => import('./package-plan/package-plan.routes'),
  },
  {
    path: 'plan',
    data: { pageTitle: 'Plans' },
    loadChildren: () => import('./plan/plan.routes'),
  },
  {
    path: 'cost-share',
    data: { pageTitle: 'CostShares' },
    loadChildren: () => import('./cost-share/cost-share.routes'),
  },
  {
    path: 'benefit',
    data: { pageTitle: 'Benefits' },
    loadChildren: () => import('./benefit/benefit.routes'),
  },
  {
    path: 'ben-service',
    data: { pageTitle: 'BenServices' },
    loadChildren: () => import('./ben-service/ben-service.routes'),
  },
  {
    path: 'ben-service-list',
    data: { pageTitle: 'BenServiceLists' },
    loadChildren: () => import('./ben-service-list/ben-service-list.routes'),
  },
  {
    path: 'blue-access',
    data: { pageTitle: 'BlueAccesses' },
    loadChildren: () => import('./blue-access/blue-access.routes'),
  },
  {
    path: 'group-access',
    data: { pageTitle: 'GroupAccesses' },
    loadChildren: () => import('./group-access/group-access.routes'),
  },
  /* jhipster-needle-add-entity-route - JHipster will add entity modules routes here */
];

export default routes;
