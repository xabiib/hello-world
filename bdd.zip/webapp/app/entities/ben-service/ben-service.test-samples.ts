import { IBenService, NewBenService } from './ben-service.model';

export const sampleWithRequiredData: IBenService = {
  id: 8889,
};

export const sampleWithPartialData: IBenService = {
  id: 10671,
  copay: 5430,
  deductible: false,
  coinsurance: 1072,
};

export const sampleWithFullData: IBenService = {
  id: 15644,
  pay: false,
  limit: 'yippee',
  copay: 23556,
  deductible: false,
  coinsurance: 2780,
};

export const sampleWithNewData: NewBenService = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
