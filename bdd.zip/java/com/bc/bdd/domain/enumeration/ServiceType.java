package com.bc.bdd.domain.enumeration;

/**
 * The ServiceType enumeration.
 */
public enum ServiceType {
    FACILITY,
    PROFESSIONAL,
    AUTISM,
    OFFICE_VISIT,
    OTHERS,
}
