package com.bc.bdd.service;

import com.bc.bdd.service.dto.PackagePlanDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.PackagePlan}.
 */
public interface PackagePlanService {
    /**
     * Save a packagePlan.
     *
     * @param packagePlanDTO the entity to save.
     * @return the persisted entity.
     */
    PackagePlanDTO save(PackagePlanDTO packagePlanDTO);

    /**
     * Updates a packagePlan.
     *
     * @param packagePlanDTO the entity to update.
     * @return the persisted entity.
     */
    PackagePlanDTO update(PackagePlanDTO packagePlanDTO);

    /**
     * Partially updates a packagePlan.
     *
     * @param packagePlanDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<PackagePlanDTO> partialUpdate(PackagePlanDTO packagePlanDTO);

    /**
     * Get all the packagePlans.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<PackagePlanDTO> findAll(Pageable pageable);

    /**
     * Get all the packagePlans with eager load of many-to-many relationships.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<PackagePlanDTO> findAllWithEagerRelationships(Pageable pageable);

    /**
     * Get the "id" packagePlan.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<PackagePlanDTO> findOne(Long id);

    /**
     * Delete the "id" packagePlan.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
