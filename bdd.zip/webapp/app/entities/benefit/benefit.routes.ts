import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import BenefitResolve from './route/benefit-routing-resolve.service';

const benefitRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/benefit.component').then(m => m.BenefitComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/benefit-detail.component').then(m => m.BenefitDetailComponent),
    resolve: {
      benefit: BenefitResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/benefit-update.component').then(m => m.BenefitUpdateComponent),
    resolve: {
      benefit: BenefitResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    loadComponent: () => import('./update/benefit-update.component').then(m => m.BenefitUpdateComponent),
    resolve: {
      benefit: BenefitResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default benefitRoute;
