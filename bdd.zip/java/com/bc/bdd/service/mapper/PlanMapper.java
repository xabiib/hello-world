package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.BenServiceList;
import com.bc.bdd.domain.CostShare;
import com.bc.bdd.domain.Plan;
import com.bc.bdd.service.dto.BenServiceListDTO;
import com.bc.bdd.service.dto.CostShareDTO;
import com.bc.bdd.service.dto.PlanDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Plan} and its DTO {@link PlanDTO}.
 */
@Mapper(componentModel = "spring")
public interface PlanMapper extends EntityMapper<PlanDTO, Plan> {
    @Mapping(target = "costShare", source = "costShare", qualifiedByName = "costShareId")
    @Mapping(target = "benServiceList", source = "benServiceList", qualifiedByName = "benServiceListId")
    PlanDTO toDto(Plan s);

    @Named("costShareId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    CostShareDTO toDtoCostShareId(CostShare costShare);

    @Named("benServiceListId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    BenServiceListDTO toDtoBenServiceListId(BenServiceList benServiceList);
}
