package com.bc.bdd.service;

import com.bc.bdd.service.dto.GroupAccessDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.GroupAccess}.
 */
public interface GroupAccessService {
    /**
     * Save a groupAccess.
     *
     * @param groupAccessDTO the entity to save.
     * @return the persisted entity.
     */
    GroupAccessDTO save(GroupAccessDTO groupAccessDTO);

    /**
     * Updates a groupAccess.
     *
     * @param groupAccessDTO the entity to update.
     * @return the persisted entity.
     */
    GroupAccessDTO update(GroupAccessDTO groupAccessDTO);

    /**
     * Partially updates a groupAccess.
     *
     * @param groupAccessDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<GroupAccessDTO> partialUpdate(GroupAccessDTO groupAccessDTO);

    /**
     * Get all the groupAccesses.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<GroupAccessDTO> findAll(Pageable pageable);

    /**
     * Get all the groupAccesses with eager load of many-to-many relationships.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<GroupAccessDTO> findAllWithEagerRelationships(Pageable pageable);

    /**
     * Get the "id" groupAccess.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<GroupAccessDTO> findOne(Long id);

    /**
     * Delete the "id" groupAccess.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
