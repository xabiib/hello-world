package com.bc.bdd.service;

import com.bc.bdd.service.dto.PackageCodeDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.PackageCode}.
 */
public interface PackageCodeService {
    /**
     * Save a packageCode.
     *
     * @param packageCodeDTO the entity to save.
     * @return the persisted entity.
     */
    PackageCodeDTO save(PackageCodeDTO packageCodeDTO);

    /**
     * Updates a packageCode.
     *
     * @param packageCodeDTO the entity to update.
     * @return the persisted entity.
     */
    PackageCodeDTO update(PackageCodeDTO packageCodeDTO);

    /**
     * Partially updates a packageCode.
     *
     * @param packageCodeDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<PackageCodeDTO> partialUpdate(PackageCodeDTO packageCodeDTO);

    /**
     * Get all the packageCodes.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<PackageCodeDTO> findAll(Pageable pageable);

    /**
     * Get all the packageCodes with eager load of many-to-many relationships.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<PackageCodeDTO> findAllWithEagerRelationships(Pageable pageable);

    /**
     * Get the "id" packageCode.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<PackageCodeDTO> findOne(Long id);

    /**
     * Delete the "id" packageCode.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
