import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import BenServiceListResolve from './route/ben-service-list-routing-resolve.service';

const benServiceListRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/ben-service-list.component').then(m => m.BenServiceListComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/ben-service-list-detail.component').then(m => m.BenServiceListDetailComponent),
    resolve: {
      benServiceList: BenServiceListResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/ben-service-list-update.component').then(m => m.BenServiceListUpdateComponent),
    resolve: {
      benServiceList: BenServiceListResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default benServiceListRoute;
