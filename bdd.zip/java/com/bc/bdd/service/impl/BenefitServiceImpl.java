package com.bc.bdd.service.impl;

import com.bc.bdd.domain.Benefit;
import com.bc.bdd.repository.BenefitRepository;
import com.bc.bdd.service.BenefitService;
import com.bc.bdd.service.dto.BenefitDTO;
import com.bc.bdd.service.mapper.BenefitMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.Benefit}.
 */
@Service
@Transactional
public class BenefitServiceImpl implements BenefitService {

    private static final Logger LOG = LoggerFactory.getLogger(BenefitServiceImpl.class);

    private final BenefitRepository benefitRepository;

    private final BenefitMapper benefitMapper;

    public BenefitServiceImpl(BenefitRepository benefitRepository, BenefitMapper benefitMapper) {
        this.benefitRepository = benefitRepository;
        this.benefitMapper = benefitMapper;
    }

    @Override
    public BenefitDTO save(BenefitDTO benefitDTO) {
        LOG.debug("Request to save Benefit : {}", benefitDTO);
        Benefit benefit = benefitMapper.toEntity(benefitDTO);
        benefit = benefitRepository.save(benefit);
        return benefitMapper.toDto(benefit);
    }

    @Override
    public BenefitDTO update(BenefitDTO benefitDTO) {
        LOG.debug("Request to update Benefit : {}", benefitDTO);
        Benefit benefit = benefitMapper.toEntity(benefitDTO);
        benefit = benefitRepository.save(benefit);
        return benefitMapper.toDto(benefit);
    }

    @Override
    public Optional<BenefitDTO> partialUpdate(BenefitDTO benefitDTO) {
        LOG.debug("Request to partially update Benefit : {}", benefitDTO);

        return benefitRepository
            .findById(benefitDTO.getId())
            .map(existingBenefit -> {
                benefitMapper.partialUpdate(existingBenefit, benefitDTO);

                return existingBenefit;
            })
            .map(benefitRepository::save)
            .map(benefitMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BenefitDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Benefits");
        return benefitRepository.findAll(pageable).map(benefitMapper::toDto);
    }

    /**
     *  Get all the benefits where BenService is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<BenefitDTO> findAllWhereBenServiceIsNull() {
        LOG.debug("Request to get all benefits where BenService is null");
        return StreamSupport.stream(benefitRepository.findAll().spliterator(), false)
            .filter(benefit -> benefit.getBenService() == null)
            .map(benefitMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<BenefitDTO> findOne(Long id) {
        LOG.debug("Request to get Benefit : {}", id);
        return benefitRepository.findById(id).map(benefitMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Benefit : {}", id);
        benefitRepository.deleteById(id);
    }
}
