/**
 * Rest layer error handling.
 */
package com.bc.bdd.web.rest.errors;
