import { IBlueAccess, NewBlueAccess } from './blue-access.model';

export const sampleWithRequiredData: IBlueAccess = {
  id: 13785,
  role: 'criminal fast',
};

export const sampleWithPartialData: IBlueAccess = {
  id: 30321,
  role: 'livid distrust',
};

export const sampleWithFullData: IBlueAccess = {
  id: 9909,
  name: 'witty athwart',
  role: 'criminal upward below',
};

export const sampleWithNewData: NewBlueAccess = {
  role: 'what pro innocently',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
