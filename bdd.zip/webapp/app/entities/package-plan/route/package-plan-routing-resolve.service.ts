import { inject } from '@angular/core';
import { HttpResponse } from '@angular/common/http';
import { ActivatedRouteSnapshot, Router } from '@angular/router';
import { EMPTY, Observable, of } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

import { IPackagePlan } from '../package-plan.model';
import { PackagePlanService } from '../service/package-plan.service';

const packagePlanResolve = (route: ActivatedRouteSnapshot): Observable<null | IPackagePlan> => {
  const id = route.params.id;
  if (id) {
    return inject(PackagePlanService)
      .find(id)
      .pipe(
        mergeMap((packagePlan: HttpResponse<IPackagePlan>) => {
          if (packagePlan.body) {
            return of(packagePlan.body);
          }
          inject(Router).navigate(['404']);
          return EMPTY;
        }),
      );
  }
  return of(null);
};

export default packagePlanResolve;
