/**
 * Repository layer.
 */
package com.bc.bdd.repository;
