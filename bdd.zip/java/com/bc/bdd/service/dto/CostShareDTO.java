package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.CostShare} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class CostShareDTO implements Serializable {

    private Long id;

    @Size(max = 10)
    private String period;

    @Size(max = 50)
    private String csAcculation;

    @Size(max = 50)
    private String csProcess;

    private Long dedINN;

    private Long dedOutN;

    private Long dedFamily;

    @Size(max = 50)
    private String fourthQuarter;

    private Boolean priorDed;

    private Boolean commonAccient;

    private Long oopINN;

    private Long oopOutN;

    private Long oopFamily;

    private Boolean dedContributeToOpp;

    private Long lifeTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getCsAcculation() {
        return csAcculation;
    }

    public void setCsAcculation(String csAcculation) {
        this.csAcculation = csAcculation;
    }

    public String getCsProcess() {
        return csProcess;
    }

    public void setCsProcess(String csProcess) {
        this.csProcess = csProcess;
    }

    public Long getDedINN() {
        return dedINN;
    }

    public void setDedINN(Long dedINN) {
        this.dedINN = dedINN;
    }

    public Long getDedOutN() {
        return dedOutN;
    }

    public void setDedOutN(Long dedOutN) {
        this.dedOutN = dedOutN;
    }

    public Long getDedFamily() {
        return dedFamily;
    }

    public void setDedFamily(Long dedFamily) {
        this.dedFamily = dedFamily;
    }

    public String getFourthQuarter() {
        return fourthQuarter;
    }

    public void setFourthQuarter(String fourthQuarter) {
        this.fourthQuarter = fourthQuarter;
    }

    public Boolean getPriorDed() {
        return priorDed;
    }

    public void setPriorDed(Boolean priorDed) {
        this.priorDed = priorDed;
    }

    public Boolean getCommonAccient() {
        return commonAccient;
    }

    public void setCommonAccient(Boolean commonAccient) {
        this.commonAccient = commonAccient;
    }

    public Long getOopINN() {
        return oopINN;
    }

    public void setOopINN(Long oopINN) {
        this.oopINN = oopINN;
    }

    public Long getOopOutN() {
        return oopOutN;
    }

    public void setOopOutN(Long oopOutN) {
        this.oopOutN = oopOutN;
    }

    public Long getOopFamily() {
        return oopFamily;
    }

    public void setOopFamily(Long oopFamily) {
        this.oopFamily = oopFamily;
    }

    public Boolean getDedContributeToOpp() {
        return dedContributeToOpp;
    }

    public void setDedContributeToOpp(Boolean dedContributeToOpp) {
        this.dedContributeToOpp = dedContributeToOpp;
    }

    public Long getLifeTime() {
        return lifeTime;
    }

    public void setLifeTime(Long lifeTime) {
        this.lifeTime = lifeTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CostShareDTO)) {
            return false;
        }

        CostShareDTO costShareDTO = (CostShareDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, costShareDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "CostShareDTO{" +
            "id=" + getId() +
            ", period='" + getPeriod() + "'" +
            ", csAcculation='" + getCsAcculation() + "'" +
            ", csProcess='" + getCsProcess() + "'" +
            ", dedINN=" + getDedINN() +
            ", dedOutN=" + getDedOutN() +
            ", dedFamily=" + getDedFamily() +
            ", fourthQuarter='" + getFourthQuarter() + "'" +
            ", priorDed='" + getPriorDed() + "'" +
            ", commonAccient='" + getCommonAccient() + "'" +
            ", oopINN=" + getOopINN() +
            ", oopOutN=" + getOopOutN() +
            ", oopFamily=" + getOopFamily() +
            ", dedContributeToOpp='" + getDedContributeToOpp() + "'" +
            ", lifeTime=" + getLifeTime() +
            "}";
    }
}
