import { ServiceType } from 'app/entities/enumerations/service-type.model';

export interface IBenefit {
  id: number;
  name?: string | null;
  type?: keyof typeof ServiceType | null;
  seq?: number | null;
  active?: boolean | null;
}

export type NewBenefit = Omit<IBenefit, 'id'> & { id: null };
