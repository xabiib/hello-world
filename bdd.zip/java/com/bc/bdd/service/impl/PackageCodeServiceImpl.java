package com.bc.bdd.service.impl;

import com.bc.bdd.domain.PackageCode;
import com.bc.bdd.repository.PackageCodeRepository;
import com.bc.bdd.service.PackageCodeService;
import com.bc.bdd.service.dto.PackageCodeDTO;
import com.bc.bdd.service.mapper.PackageCodeMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.PackageCode}.
 */
@Service
@Transactional
public class PackageCodeServiceImpl implements PackageCodeService {

    private static final Logger LOG = LoggerFactory.getLogger(PackageCodeServiceImpl.class);

    private final PackageCodeRepository packageCodeRepository;

    private final PackageCodeMapper packageCodeMapper;

    public PackageCodeServiceImpl(PackageCodeRepository packageCodeRepository, PackageCodeMapper packageCodeMapper) {
        this.packageCodeRepository = packageCodeRepository;
        this.packageCodeMapper = packageCodeMapper;
    }

    @Override
    public PackageCodeDTO save(PackageCodeDTO packageCodeDTO) {
        LOG.debug("Request to save PackageCode : {}", packageCodeDTO);
        PackageCode packageCode = packageCodeMapper.toEntity(packageCodeDTO);
        packageCode = packageCodeRepository.save(packageCode);
        return packageCodeMapper.toDto(packageCode);
    }

    @Override
    public PackageCodeDTO update(PackageCodeDTO packageCodeDTO) {
        LOG.debug("Request to update PackageCode : {}", packageCodeDTO);
        PackageCode packageCode = packageCodeMapper.toEntity(packageCodeDTO);
        packageCode = packageCodeRepository.save(packageCode);
        return packageCodeMapper.toDto(packageCode);
    }

    @Override
    public Optional<PackageCodeDTO> partialUpdate(PackageCodeDTO packageCodeDTO) {
        LOG.debug("Request to partially update PackageCode : {}", packageCodeDTO);

        return packageCodeRepository
            .findById(packageCodeDTO.getId())
            .map(existingPackageCode -> {
                packageCodeMapper.partialUpdate(existingPackageCode, packageCodeDTO);

                return existingPackageCode;
            })
            .map(packageCodeRepository::save)
            .map(packageCodeMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PackageCodeDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all PackageCodes");
        return packageCodeRepository.findAll(pageable).map(packageCodeMapper::toDto);
    }

    public Page<PackageCodeDTO> findAllWithEagerRelationships(Pageable pageable) {
        return packageCodeRepository.findAllWithEagerRelationships(pageable).map(packageCodeMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PackageCodeDTO> findOne(Long id) {
        LOG.debug("Request to get PackageCode : {}", id);
        return packageCodeRepository.findOneWithEagerRelationships(id).map(packageCodeMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete PackageCode : {}", id);
        packageCodeRepository.deleteById(id);
    }
}
