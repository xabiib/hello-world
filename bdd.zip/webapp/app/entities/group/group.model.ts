import dayjs from 'dayjs/esm';

export interface IGroup {
  id: number;
  name?: string | null;
  num?: string | null;
  effective?: dayjs.Dayjs | null;
  termination?: dayjs.Dayjs | null;
  customerId?: string | null;
}

export type NewGroup = Omit<IGroup, 'id'> & { id: null };
