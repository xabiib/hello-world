import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import CostShareResolve from './route/cost-share-routing-resolve.service';

const costShareRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/cost-share.component').then(m => m.CostShareComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/cost-share-detail.component').then(m => m.CostShareDetailComponent),
    resolve: {
      costShare: CostShareResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/cost-share-update.component').then(m => m.CostShareUpdateComponent),
    resolve: {
      costShare: CostShareResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    loadComponent: () => import('./update/cost-share-update.component').then(m => m.CostShareUpdateComponent),
    resolve: {
      costShare: CostShareResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default costShareRoute;
