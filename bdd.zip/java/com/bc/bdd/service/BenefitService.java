package com.bc.bdd.service;

import com.bc.bdd.service.dto.BenefitDTO;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.Benefit}.
 */
public interface BenefitService {
    /**
     * Save a benefit.
     *
     * @param benefitDTO the entity to save.
     * @return the persisted entity.
     */
    BenefitDTO save(BenefitDTO benefitDTO);

    /**
     * Updates a benefit.
     *
     * @param benefitDTO the entity to update.
     * @return the persisted entity.
     */
    BenefitDTO update(BenefitDTO benefitDTO);

    /**
     * Partially updates a benefit.
     *
     * @param benefitDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<BenefitDTO> partialUpdate(BenefitDTO benefitDTO);

    /**
     * Get all the benefits.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<BenefitDTO> findAll(Pageable pageable);

    /**
     * Get all the BenefitDTO where BenService is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<BenefitDTO> findAllWhereBenServiceIsNull();

    /**
     * Get the "id" benefit.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<BenefitDTO> findOne(Long id);

    /**
     * Delete the "id" benefit.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
