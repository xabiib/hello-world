package com.bc.bdd.service.impl;

import com.bc.bdd.domain.BlueAccess;
import com.bc.bdd.repository.BlueAccessRepository;
import com.bc.bdd.service.BlueAccessService;
import com.bc.bdd.service.dto.BlueAccessDTO;
import com.bc.bdd.service.mapper.BlueAccessMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.BlueAccess}.
 */
@Service
@Transactional
public class BlueAccessServiceImpl implements BlueAccessService {

    private static final Logger LOG = LoggerFactory.getLogger(BlueAccessServiceImpl.class);

    private final BlueAccessRepository blueAccessRepository;

    private final BlueAccessMapper blueAccessMapper;

    public BlueAccessServiceImpl(BlueAccessRepository blueAccessRepository, BlueAccessMapper blueAccessMapper) {
        this.blueAccessRepository = blueAccessRepository;
        this.blueAccessMapper = blueAccessMapper;
    }

    @Override
    public BlueAccessDTO save(BlueAccessDTO blueAccessDTO) {
        LOG.debug("Request to save BlueAccess : {}", blueAccessDTO);
        BlueAccess blueAccess = blueAccessMapper.toEntity(blueAccessDTO);
        blueAccess = blueAccessRepository.save(blueAccess);
        return blueAccessMapper.toDto(blueAccess);
    }

    @Override
    public BlueAccessDTO update(BlueAccessDTO blueAccessDTO) {
        LOG.debug("Request to update BlueAccess : {}", blueAccessDTO);
        BlueAccess blueAccess = blueAccessMapper.toEntity(blueAccessDTO);
        blueAccess = blueAccessRepository.save(blueAccess);
        return blueAccessMapper.toDto(blueAccess);
    }

    @Override
    public Optional<BlueAccessDTO> partialUpdate(BlueAccessDTO blueAccessDTO) {
        LOG.debug("Request to partially update BlueAccess : {}", blueAccessDTO);

        return blueAccessRepository
            .findById(blueAccessDTO.getId())
            .map(existingBlueAccess -> {
                blueAccessMapper.partialUpdate(existingBlueAccess, blueAccessDTO);

                return existingBlueAccess;
            })
            .map(blueAccessRepository::save)
            .map(blueAccessMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BlueAccessDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all BlueAccesses");
        return blueAccessRepository.findAll(pageable).map(blueAccessMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<BlueAccessDTO> findOne(Long id) {
        LOG.debug("Request to get BlueAccess : {}", id);
        return blueAccessRepository.findById(id).map(blueAccessMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete BlueAccess : {}", id);
        blueAccessRepository.deleteById(id);
    }
}
