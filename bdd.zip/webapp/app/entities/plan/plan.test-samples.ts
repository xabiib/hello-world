import { IPlan, NewPlan } from './plan.model';

export const sampleWithRequiredData: IPlan = {
  id: 24662,
  name: 'since scholarly alongside',
};

export const sampleWithPartialData: IPlan = {
  id: 12267,
  name: 'wherever porcupine',
};

export const sampleWithFullData: IPlan = {
  id: 19135,
  name: 'when linear versus',
};

export const sampleWithNewData: NewPlan = {
  name: 'beside',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
