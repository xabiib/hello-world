package com.bc.bdd.repository;

import com.bc.bdd.domain.PackagePlan;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the PackagePlan entity.
 */
@Repository
public interface PackagePlanRepository extends JpaRepository<PackagePlan, Long> {
    @Query("select packagePlan from PackagePlan packagePlan where packagePlan.user.login = ?#{authentication.name}")
    List<PackagePlan> findByUserIsCurrentUser();

    default Optional<PackagePlan> findOneWithEagerRelationships(Long id) {
        return this.findOneWithToOneRelationships(id);
    }

    default List<PackagePlan> findAllWithEagerRelationships() {
        return this.findAllWithToOneRelationships();
    }

    default Page<PackagePlan> findAllWithEagerRelationships(Pageable pageable) {
        return this.findAllWithToOneRelationships(pageable);
    }

    @Query(
        value = "select packagePlan from PackagePlan packagePlan left join fetch packagePlan.packagecode left join fetch packagePlan.user left join fetch packagePlan.plan",
        countQuery = "select count(packagePlan) from PackagePlan packagePlan"
    )
    Page<PackagePlan> findAllWithToOneRelationships(Pageable pageable);

    @Query(
        "select packagePlan from PackagePlan packagePlan left join fetch packagePlan.packagecode left join fetch packagePlan.user left join fetch packagePlan.plan"
    )
    List<PackagePlan> findAllWithToOneRelationships();

    @Query(
        "select packagePlan from PackagePlan packagePlan left join fetch packagePlan.packagecode left join fetch packagePlan.user left join fetch packagePlan.plan where packagePlan.id =:id"
    )
    Optional<PackagePlan> findOneWithToOneRelationships(@Param("id") Long id);
}
