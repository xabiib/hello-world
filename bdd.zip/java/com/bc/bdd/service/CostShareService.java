package com.bc.bdd.service;

import com.bc.bdd.service.dto.CostShareDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.CostShare}.
 */
public interface CostShareService {
    /**
     * Save a costShare.
     *
     * @param costShareDTO the entity to save.
     * @return the persisted entity.
     */
    CostShareDTO save(CostShareDTO costShareDTO);

    /**
     * Updates a costShare.
     *
     * @param costShareDTO the entity to update.
     * @return the persisted entity.
     */
    CostShareDTO update(CostShareDTO costShareDTO);

    /**
     * Partially updates a costShare.
     *
     * @param costShareDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<CostShareDTO> partialUpdate(CostShareDTO costShareDTO);

    /**
     * Get all the costShares.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<CostShareDTO> findAll(Pageable pageable);

    /**
     * Get the "id" costShare.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<CostShareDTO> findOne(Long id);

    /**
     * Delete the "id" costShare.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
