package com.bc.bdd.service;

import com.bc.bdd.service.dto.BenServiceListDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.BenServiceList}.
 */
public interface BenServiceListService {
    /**
     * Save a benServiceList.
     *
     * @param benServiceListDTO the entity to save.
     * @return the persisted entity.
     */
    BenServiceListDTO save(BenServiceListDTO benServiceListDTO);

    /**
     * Updates a benServiceList.
     *
     * @param benServiceListDTO the entity to update.
     * @return the persisted entity.
     */
    BenServiceListDTO update(BenServiceListDTO benServiceListDTO);

    /**
     * Partially updates a benServiceList.
     *
     * @param benServiceListDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<BenServiceListDTO> partialUpdate(BenServiceListDTO benServiceListDTO);

    /**
     * Get all the benServiceLists.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<BenServiceListDTO> findAll(Pageable pageable);

    /**
     * Get the "id" benServiceList.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<BenServiceListDTO> findOne(Long id);

    /**
     * Delete the "id" benServiceList.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
