import { TestBed } from '@angular/core/testing';

import { sampleWithNewData, sampleWithRequiredData } from '../package-plan.test-samples';

import { PackagePlanFormService } from './package-plan-form.service';

describe('PackagePlan Form Service', () => {
  let service: PackagePlanFormService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PackagePlanFormService);
  });

  describe('Service methods', () => {
    describe('createPackagePlanFormGroup', () => {
      it('should create a new form with FormControl', () => {
        const formGroup = service.createPackagePlanFormGroup();

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            effective: expect.any(Object),
            termination: expect.any(Object),
            date: expect.any(Object),
            status: expect.any(Object),
            packagecode: expect.any(Object),
            user: expect.any(Object),
            plan: expect.any(Object),
          }),
        );
      });

      it('passing IPackagePlan should create a new form with FormGroup', () => {
        const formGroup = service.createPackagePlanFormGroup(sampleWithRequiredData);

        expect(formGroup.controls).toEqual(
          expect.objectContaining({
            id: expect.any(Object),
            name: expect.any(Object),
            effective: expect.any(Object),
            termination: expect.any(Object),
            date: expect.any(Object),
            status: expect.any(Object),
            packagecode: expect.any(Object),
            user: expect.any(Object),
            plan: expect.any(Object),
          }),
        );
      });
    });

    describe('getPackagePlan', () => {
      it('should return NewPackagePlan for default PackagePlan initial value', () => {
        const formGroup = service.createPackagePlanFormGroup(sampleWithNewData);

        const packagePlan = service.getPackagePlan(formGroup) as any;

        expect(packagePlan).toMatchObject(sampleWithNewData);
      });

      it('should return NewPackagePlan for empty PackagePlan initial value', () => {
        const formGroup = service.createPackagePlanFormGroup();

        const packagePlan = service.getPackagePlan(formGroup) as any;

        expect(packagePlan).toMatchObject({});
      });

      it('should return IPackagePlan', () => {
        const formGroup = service.createPackagePlanFormGroup(sampleWithRequiredData);

        const packagePlan = service.getPackagePlan(formGroup) as any;

        expect(packagePlan).toMatchObject(sampleWithRequiredData);
      });
    });

    describe('resetForm', () => {
      it('passing IPackagePlan should not enable id FormControl', () => {
        const formGroup = service.createPackagePlanFormGroup();
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, sampleWithRequiredData);

        expect(formGroup.controls.id.disabled).toBe(true);
      });

      it('passing NewPackagePlan should disable id FormControl', () => {
        const formGroup = service.createPackagePlanFormGroup(sampleWithRequiredData);
        expect(formGroup.controls.id.disabled).toBe(true);

        service.resetForm(formGroup, { id: null });

        expect(formGroup.controls.id.disabled).toBe(true);
      });
    });
  });
});
