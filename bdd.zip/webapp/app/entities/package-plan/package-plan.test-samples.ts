import dayjs from 'dayjs/esm';

import { IPackagePlan, NewPackagePlan } from './package-plan.model';

export const sampleWithRequiredData: IPackagePlan = {
  id: 5181,
};

export const sampleWithPartialData: IPackagePlan = {
  id: 8429,
  name: 'miserably corduroy crop',
  effective: dayjs('2024-09-02'),
  termination: dayjs('2024-09-02'),
  date: dayjs('2024-09-01T18:51'),
  status: 'injunction',
};

export const sampleWithFullData: IPackagePlan = {
  id: 27282,
  name: 'steel rejoice',
  effective: dayjs('2024-09-02'),
  termination: dayjs('2024-09-01'),
  date: dayjs('2024-09-02T04:16'),
  status: 'ouch yum',
};

export const sampleWithNewData: NewPackagePlan = {
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
