import { IUser } from './user.model';

export const sampleWithRequiredData: IUser = {
  id: 11606,
  login: 'zpFhe',
};

export const sampleWithPartialData: IUser = {
  id: 25405,
  login: '8y_$S@L\\9ITL\\paEY\\k01s2\\_AKu',
};

export const sampleWithFullData: IUser = {
  id: 24637,
  login: 'V8',
};
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
