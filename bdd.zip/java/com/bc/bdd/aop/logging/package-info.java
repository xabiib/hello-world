/**
 * Logging aspect.
 */
package com.bc.bdd.aop.logging;
