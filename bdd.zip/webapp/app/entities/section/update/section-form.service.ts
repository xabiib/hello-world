import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ISection, NewSection } from '../section.model';

/**
 * A partial Type with required key is used as form input.
 */
type PartialWithRequiredKeyOf<T extends { id: unknown }> = Partial<Omit<T, 'id'>> & { id: T['id'] };

/**
 * Type for createFormGroup and resetForm argument.
 * It accepts ISection for edit and NewSectionFormGroupInput for create.
 */
type SectionFormGroupInput = ISection | PartialWithRequiredKeyOf<NewSection>;

type SectionFormDefaults = Pick<NewSection, 'id' | 'active'>;

type SectionFormGroupContent = {
  id: FormControl<ISection['id'] | NewSection['id']>;
  name: FormControl<ISection['name']>;
  num: FormControl<ISection['num']>;
  active: FormControl<ISection['active']>;
  group: FormControl<ISection['group']>;
};

export type SectionFormGroup = FormGroup<SectionFormGroupContent>;

@Injectable({ providedIn: 'root' })
export class SectionFormService {
  createSectionFormGroup(section: SectionFormGroupInput = { id: null }): SectionFormGroup {
    const sectionRawValue = {
      ...this.getFormDefaults(),
      ...section,
    };
    return new FormGroup<SectionFormGroupContent>({
      id: new FormControl(
        { value: sectionRawValue.id, disabled: true },
        {
          nonNullable: true,
          validators: [Validators.required],
        },
      ),
      name: new FormControl(sectionRawValue.name, {
        validators: [Validators.maxLength(100)],
      }),
      num: new FormControl(sectionRawValue.num, {
        validators: [Validators.required, Validators.maxLength(4)],
      }),
      active: new FormControl(sectionRawValue.active),
      group: new FormControl(sectionRawValue.group),
    });
  }

  getSection(form: SectionFormGroup): ISection | NewSection {
    return form.getRawValue() as ISection | NewSection;
  }

  resetForm(form: SectionFormGroup, section: SectionFormGroupInput): void {
    const sectionRawValue = { ...this.getFormDefaults(), ...section };
    form.reset(
      {
        ...sectionRawValue,
        id: { value: sectionRawValue.id, disabled: true },
      } as any /* cast to workaround https://github.com/angular/angular/issues/46458 */,
    );
  }

  private getFormDefaults(): SectionFormDefaults {
    return {
      id: null,
      active: false,
    };
  }
}
