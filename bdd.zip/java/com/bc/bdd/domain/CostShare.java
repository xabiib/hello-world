package com.bc.bdd.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

/**
 * A CostShare.
 */
@Entity
@Table(name = "cost_share")
@SuppressWarnings("common-java:DuplicatedBlocks")
public class CostShare implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @Size(max = 10)
    @Column(name = "period", length = 10)
    private String period;

    @Size(max = 50)
    @Column(name = "cs_acculation", length = 50)
    private String csAcculation;

    @Size(max = 50)
    @Column(name = "cs_process", length = 50)
    private String csProcess;

    @Column(name = "ded_inn")
    private Long dedINN;

    @Column(name = "ded_out_n")
    private Long dedOutN;

    @Column(name = "ded_family")
    private Long dedFamily;

    @Size(max = 50)
    @Column(name = "fourth_quarter", length = 50)
    private String fourthQuarter;

    @Column(name = "prior_ded")
    private Boolean priorDed;

    @Column(name = "common_accient")
    private Boolean commonAccient;

    @Column(name = "oop_inn")
    private Long oopINN;

    @Column(name = "oop_out_n")
    private Long oopOutN;

    @Column(name = "oop_family")
    private Long oopFamily;

    @Column(name = "ded_contribute_to_opp")
    private Boolean dedContributeToOpp;

    @Column(name = "life_time")
    private Long lifeTime;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "costShare")
    @JsonIgnoreProperties(value = { "costShare", "benServiceList" }, allowSetters = true)
    private Set<Plan> plans = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public CostShare id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPeriod() {
        return this.period;
    }

    public CostShare period(String period) {
        this.setPeriod(period);
        return this;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public String getCsAcculation() {
        return this.csAcculation;
    }

    public CostShare csAcculation(String csAcculation) {
        this.setCsAcculation(csAcculation);
        return this;
    }

    public void setCsAcculation(String csAcculation) {
        this.csAcculation = csAcculation;
    }

    public String getCsProcess() {
        return this.csProcess;
    }

    public CostShare csProcess(String csProcess) {
        this.setCsProcess(csProcess);
        return this;
    }

    public void setCsProcess(String csProcess) {
        this.csProcess = csProcess;
    }

    public Long getDedINN() {
        return this.dedINN;
    }

    public CostShare dedINN(Long dedINN) {
        this.setDedINN(dedINN);
        return this;
    }

    public void setDedINN(Long dedINN) {
        this.dedINN = dedINN;
    }

    public Long getDedOutN() {
        return this.dedOutN;
    }

    public CostShare dedOutN(Long dedOutN) {
        this.setDedOutN(dedOutN);
        return this;
    }

    public void setDedOutN(Long dedOutN) {
        this.dedOutN = dedOutN;
    }

    public Long getDedFamily() {
        return this.dedFamily;
    }

    public CostShare dedFamily(Long dedFamily) {
        this.setDedFamily(dedFamily);
        return this;
    }

    public void setDedFamily(Long dedFamily) {
        this.dedFamily = dedFamily;
    }

    public String getFourthQuarter() {
        return this.fourthQuarter;
    }

    public CostShare fourthQuarter(String fourthQuarter) {
        this.setFourthQuarter(fourthQuarter);
        return this;
    }

    public void setFourthQuarter(String fourthQuarter) {
        this.fourthQuarter = fourthQuarter;
    }

    public Boolean getPriorDed() {
        return this.priorDed;
    }

    public CostShare priorDed(Boolean priorDed) {
        this.setPriorDed(priorDed);
        return this;
    }

    public void setPriorDed(Boolean priorDed) {
        this.priorDed = priorDed;
    }

    public Boolean getCommonAccient() {
        return this.commonAccient;
    }

    public CostShare commonAccient(Boolean commonAccient) {
        this.setCommonAccient(commonAccient);
        return this;
    }

    public void setCommonAccient(Boolean commonAccient) {
        this.commonAccient = commonAccient;
    }

    public Long getOopINN() {
        return this.oopINN;
    }

    public CostShare oopINN(Long oopINN) {
        this.setOopINN(oopINN);
        return this;
    }

    public void setOopINN(Long oopINN) {
        this.oopINN = oopINN;
    }

    public Long getOopOutN() {
        return this.oopOutN;
    }

    public CostShare oopOutN(Long oopOutN) {
        this.setOopOutN(oopOutN);
        return this;
    }

    public void setOopOutN(Long oopOutN) {
        this.oopOutN = oopOutN;
    }

    public Long getOopFamily() {
        return this.oopFamily;
    }

    public CostShare oopFamily(Long oopFamily) {
        this.setOopFamily(oopFamily);
        return this;
    }

    public void setOopFamily(Long oopFamily) {
        this.oopFamily = oopFamily;
    }

    public Boolean getDedContributeToOpp() {
        return this.dedContributeToOpp;
    }

    public CostShare dedContributeToOpp(Boolean dedContributeToOpp) {
        this.setDedContributeToOpp(dedContributeToOpp);
        return this;
    }

    public void setDedContributeToOpp(Boolean dedContributeToOpp) {
        this.dedContributeToOpp = dedContributeToOpp;
    }

    public Long getLifeTime() {
        return this.lifeTime;
    }

    public CostShare lifeTime(Long lifeTime) {
        this.setLifeTime(lifeTime);
        return this;
    }

    public void setLifeTime(Long lifeTime) {
        this.lifeTime = lifeTime;
    }

    public Set<Plan> getPlans() {
        return this.plans;
    }

    public void setPlans(Set<Plan> plans) {
        if (this.plans != null) {
            this.plans.forEach(i -> i.setCostShare(null));
        }
        if (plans != null) {
            plans.forEach(i -> i.setCostShare(this));
        }
        this.plans = plans;
    }

    public CostShare plans(Set<Plan> plans) {
        this.setPlans(plans);
        return this;
    }

    public CostShare addPlan(Plan plan) {
        this.plans.add(plan);
        plan.setCostShare(this);
        return this;
    }

    public CostShare removePlan(Plan plan) {
        this.plans.remove(plan);
        plan.setCostShare(null);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof CostShare)) {
            return false;
        }
        return getId() != null && getId().equals(((CostShare) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "CostShare{" +
            "id=" + getId() +
            ", period='" + getPeriod() + "'" +
            ", csAcculation='" + getCsAcculation() + "'" +
            ", csProcess='" + getCsProcess() + "'" +
            ", dedINN=" + getDedINN() +
            ", dedOutN=" + getDedOutN() +
            ", dedFamily=" + getDedFamily() +
            ", fourthQuarter='" + getFourthQuarter() + "'" +
            ", priorDed='" + getPriorDed() + "'" +
            ", commonAccient='" + getCommonAccient() + "'" +
            ", oopINN=" + getOopINN() +
            ", oopOutN=" + getOopOutN() +
            ", oopFamily=" + getOopFamily() +
            ", dedContributeToOpp='" + getDedContributeToOpp() + "'" +
            ", lifeTime=" + getLifeTime() +
            "}";
    }
}
