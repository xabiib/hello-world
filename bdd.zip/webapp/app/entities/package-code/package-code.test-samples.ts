import { IPackageCode, NewPackageCode } from './package-code.model';

export const sampleWithRequiredData: IPackageCode = {
  id: 17670,
  num: 'jud',
};

export const sampleWithPartialData: IPackageCode = {
  id: 31118,
  num: 'yip',
};

export const sampleWithFullData: IPackageCode = {
  id: 9169,
  name: 'attachment er',
  num: 'chi',
};

export const sampleWithNewData: NewPackageCode = {
  num: 'rou',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
