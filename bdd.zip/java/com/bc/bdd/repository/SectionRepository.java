package com.bc.bdd.repository;

import com.bc.bdd.domain.Section;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the Section entity.
 */
@Repository
public interface SectionRepository extends JpaRepository<Section, Long> {
    default Optional<Section> findOneWithEagerRelationships(Long id) {
        return this.findOneWithToOneRelationships(id);
    }

    default List<Section> findAllWithEagerRelationships() {
        return this.findAllWithToOneRelationships();
    }

    default Page<Section> findAllWithEagerRelationships(Pageable pageable) {
        return this.findAllWithToOneRelationships(pageable);
    }

    @Query(
        value = "select section from Section section left join fetch section.group",
        countQuery = "select count(section) from Section section"
    )
    Page<Section> findAllWithToOneRelationships(Pageable pageable);

    @Query("select section from Section section left join fetch section.group")
    List<Section> findAllWithToOneRelationships();

    @Query("select section from Section section left join fetch section.group where section.id =:id")
    Optional<Section> findOneWithToOneRelationships(@Param("id") Long id);
}
