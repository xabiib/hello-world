package com.bc.bdd.repository;

import com.bc.bdd.domain.BenService;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the BenService entity.
 */
@SuppressWarnings("unused")
@Repository
public interface BenServiceRepository extends JpaRepository<BenService, Long> {}
