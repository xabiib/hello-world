import { IGroup } from 'app/entities/group/group.model';
import { IBlueAccess } from 'app/entities/blue-access/blue-access.model';

export interface IGroupAccess {
  id: number;
  name?: string | null;
  group?: Pick<IGroup, 'id' | 'num'> | null;
  blueAccess?: Pick<IBlueAccess, 'id' | 'role'> | null;
}

export type NewGroupAccess = Omit<IGroupAccess, 'id'> & { id: null };
