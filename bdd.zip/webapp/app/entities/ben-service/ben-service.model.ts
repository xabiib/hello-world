import { IBenefit } from 'app/entities/benefit/benefit.model';
import { IBenServiceList } from 'app/entities/ben-service-list/ben-service-list.model';

export interface IBenService {
  id: number;
  pay?: boolean | null;
  limit?: string | null;
  copay?: number | null;
  deductible?: boolean | null;
  coinsurance?: number | null;
  benefit?: Pick<IBenefit, 'id'> | null;
  benServiceList?: Pick<IBenServiceList, 'id'> | null;
}

export type NewBenService = Omit<IBenService, 'id'> & { id: null };
