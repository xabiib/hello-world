export interface ICostShare {
  id: number;
  period?: string | null;
  csAcculation?: string | null;
  csProcess?: string | null;
  dedINN?: number | null;
  dedOutN?: number | null;
  dedFamily?: number | null;
  fourthQuarter?: string | null;
  priorDed?: boolean | null;
  commonAccient?: boolean | null;
  oopINN?: number | null;
  oopOutN?: number | null;
  oopFamily?: number | null;
  dedContributeToOpp?: boolean | null;
  lifeTime?: number | null;
}

export type NewCostShare = Omit<ICostShare, 'id'> & { id: null };
