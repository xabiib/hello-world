package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.PackageCode;
import com.bc.bdd.domain.PackagePlan;
import com.bc.bdd.domain.Plan;
import com.bc.bdd.domain.User;
import com.bc.bdd.service.dto.PackageCodeDTO;
import com.bc.bdd.service.dto.PackagePlanDTO;
import com.bc.bdd.service.dto.PlanDTO;
import com.bc.bdd.service.dto.UserDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link PackagePlan} and its DTO {@link PackagePlanDTO}.
 */
@Mapper(componentModel = "spring")
public interface PackagePlanMapper extends EntityMapper<PackagePlanDTO, PackagePlan> {
    @Mapping(target = "packagecode", source = "packagecode", qualifiedByName = "packageCodeNum")
    @Mapping(target = "user", source = "user", qualifiedByName = "userLogin")
    @Mapping(target = "plan", source = "plan", qualifiedByName = "planName")
    PackagePlanDTO toDto(PackagePlan s);

    @Named("packageCodeNum")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "num", source = "num")
    PackageCodeDTO toDtoPackageCodeNum(PackageCode packageCode);

    @Named("userLogin")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "login", source = "login")
    UserDTO toDtoUserLogin(User user);

    @Named("planName")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "name", source = "name")
    PlanDTO toDtoPlanName(Plan plan);
}
