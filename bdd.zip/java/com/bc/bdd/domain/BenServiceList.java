package com.bc.bdd.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

/**
 * A BenServiceList.
 */
@Entity
@Table(name = "ben_service_list")
@SuppressWarnings("common-java:DuplicatedBlocks")
public class BenServiceList implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "benServiceList")
    @JsonIgnoreProperties(value = { "benefit", "benServiceList" }, allowSetters = true)
    private Set<BenService> benServices = new HashSet<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "benServiceList")
    @JsonIgnoreProperties(value = { "costShare", "benServiceList" }, allowSetters = true)
    private Set<Plan> plans = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public BenServiceList id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Set<BenService> getBenServices() {
        return this.benServices;
    }

    public void setBenServices(Set<BenService> benServices) {
        if (this.benServices != null) {
            this.benServices.forEach(i -> i.setBenServiceList(null));
        }
        if (benServices != null) {
            benServices.forEach(i -> i.setBenServiceList(this));
        }
        this.benServices = benServices;
    }

    public BenServiceList benServices(Set<BenService> benServices) {
        this.setBenServices(benServices);
        return this;
    }

    public BenServiceList addBenService(BenService benService) {
        this.benServices.add(benService);
        benService.setBenServiceList(this);
        return this;
    }

    public BenServiceList removeBenService(BenService benService) {
        this.benServices.remove(benService);
        benService.setBenServiceList(null);
        return this;
    }

    public Set<Plan> getPlans() {
        return this.plans;
    }

    public void setPlans(Set<Plan> plans) {
        if (this.plans != null) {
            this.plans.forEach(i -> i.setBenServiceList(null));
        }
        if (plans != null) {
            plans.forEach(i -> i.setBenServiceList(this));
        }
        this.plans = plans;
    }

    public BenServiceList plans(Set<Plan> plans) {
        this.setPlans(plans);
        return this;
    }

    public BenServiceList addPlan(Plan plan) {
        this.plans.add(plan);
        plan.setBenServiceList(this);
        return this;
    }

    public BenServiceList removePlan(Plan plan) {
        this.plans.remove(plan);
        plan.setBenServiceList(null);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof BenServiceList)) {
            return false;
        }
        return getId() != null && getId().equals(((BenServiceList) o).getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "BenServiceList{" +
            "id=" + getId() +
            "}";
    }
}
