import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Inject,
  Output,
} from "@angular/core";
import {
  MAT_DIALOG_DATA,
  MatDialogRef,
  MatDialogModule,
} from "@angular/material/dialog";
import {
  FormControl,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatButtonModule } from "@angular/material/button";
import { MatInputModule } from "@angular/material/input";
import { Project } from "../project.model";
import { MatSelectModule } from "@angular/material/select";

@Component({
  selector: "app-project-dialog",
  standalone: true,
  imports: [
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatSelectModule,
    MatDialogModule,
  ],
  template: `
    <h1 mat-dialog-title>
      {{ data.title }}
    </h1>
    <div mat-dialog-content>
      <form class="project-form" [formGroup]="projectForm">
        <input type="hidden" formControlName="claimScenarioId" />

        <mat-form-field [appearance]="'outline'">
          <mat-label>Project</mat-label>
          <input matInput formControlName="descriptionText" />
        </mat-form-field>

        <mat-form-field [appearance]="'outline'">
          <mat-label>User Id</mat-label>
          <input matInput type="string" formControlName="userId" />
        </mat-form-field>

        <mat-form-field [appearance]="'outline'">
          <mat-label>PrivateInd</mat-label>
          <input matInput type="number" formControlName="privateInd" />
        </mat-form-field>
      </form>
    </div>
    <div mat-dialog-actions>
      <button
        mat-raised-button
        color="primary"
        (click)="onSubmit()"
        [disabled]="projectForm.invalid"
      >
        Save
      </button>
      <button mat-raised-button color="warn" (click)="onCanceled()">
        Close
      </button>
    </div>
  `,
  styles: [
    `
      .project-form {
        padding: 10px;
        display: flex;
        flex-direction: column;
        gap: 20px;
      }

      mat-form-field {
        width: 500px;
      }
    
    `,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProjectDialogComponent {
  @Output() sumbit = new EventEmitter<Project>();
  projectForm: FormGroup = new FormGroup({
    claimScenarioId: new FormControl<number>(0),
    descriptionText: new FormControl<string>("", Validators.required),
    userId: new FormControl<string>("habib", Validators.required),
    privateInd: new FormControl<number>(0, Validators.required),
  });

  selectedOption = 0 ;

  onCanceled() {
    this.dialogRef.close();
  }

  onSubmit() {
    if (this.projectForm.valid) {
      const Project: Project = Object.assign(this.projectForm.value) as Project;
      this.sumbit.emit(Project);
    }
  }

  //*  // .Project-form {
      //   display: grid;
      //   grid-template-columns: repeat(
      //     3,
      //     1fr
      //   ); /* Three columns with equal width */
      //   gap: 16px; /* Adjust the gap between columns as needed */
      // }



  constructor(
    public dialogRef: MatDialogRef<ProjectDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      project: Project | null;
      title: string;
    //  categories: CategoryModel[];
    }
  ) {
    if (data.project != null) {
      this.selectedOption = data.project.claimScenarioId ;
     // this.categoryName = this.data.categories[data.Project.categoryId].categoryName ;
      this.projectForm.patchValue(data.project);
    }
  }
}
