package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.BenServiceList;
import com.bc.bdd.service.dto.BenServiceListDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link BenServiceList} and its DTO {@link BenServiceListDTO}.
 */
@Mapper(componentModel = "spring")
public interface BenServiceListMapper extends EntityMapper<BenServiceListDTO, BenServiceList> {}
