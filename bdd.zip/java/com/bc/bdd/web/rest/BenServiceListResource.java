package com.bc.bdd.web.rest;

import com.bc.bdd.repository.BenServiceListRepository;
import com.bc.bdd.service.BenServiceListService;
import com.bc.bdd.service.dto.BenServiceListDTO;
import com.bc.bdd.web.rest.errors.BadRequestAlertException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.PaginationUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.bc.bdd.domain.BenServiceList}.
 */
@RestController
@RequestMapping("/api/ben-service-lists")
public class BenServiceListResource {

    private static final Logger LOG = LoggerFactory.getLogger(BenServiceListResource.class);

    private static final String ENTITY_NAME = "benServiceList";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final BenServiceListService benServiceListService;

    private final BenServiceListRepository benServiceListRepository;

    public BenServiceListResource(BenServiceListService benServiceListService, BenServiceListRepository benServiceListRepository) {
        this.benServiceListService = benServiceListService;
        this.benServiceListRepository = benServiceListRepository;
    }

    /**
     * {@code POST  /ben-service-lists} : Create a new benServiceList.
     *
     * @param benServiceListDTO the benServiceListDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new benServiceListDTO, or with status {@code 400 (Bad Request)} if the benServiceList has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<BenServiceListDTO> createBenServiceList(@RequestBody BenServiceListDTO benServiceListDTO)
        throws URISyntaxException {
        LOG.debug("REST request to save BenServiceList : {}", benServiceListDTO);
        if (benServiceListDTO.getId() != null) {
            throw new BadRequestAlertException("A new benServiceList cannot already have an ID", ENTITY_NAME, "idexists");
        }
        benServiceListDTO = benServiceListService.save(benServiceListDTO);
        return ResponseEntity.created(new URI("/api/ben-service-lists/" + benServiceListDTO.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, false, ENTITY_NAME, benServiceListDTO.getId().toString()))
            .body(benServiceListDTO);
    }

    /**
     * {@code GET  /ben-service-lists} : get all the benServiceLists.
     *
     * @param pageable the pagination information.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of benServiceLists in body.
     */
    @GetMapping("")
    public ResponseEntity<List<BenServiceListDTO>> getAllBenServiceLists(
        @org.springdoc.core.annotations.ParameterObject Pageable pageable
    ) {
        LOG.debug("REST request to get a page of BenServiceLists");
        Page<BenServiceListDTO> page = benServiceListService.findAll(pageable);
        HttpHeaders headers = PaginationUtil.generatePaginationHttpHeaders(ServletUriComponentsBuilder.fromCurrentRequest(), page);
        return ResponseEntity.ok().headers(headers).body(page.getContent());
    }

    /**
     * {@code GET  /ben-service-lists/:id} : get the "id" benServiceList.
     *
     * @param id the id of the benServiceListDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the benServiceListDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<BenServiceListDTO> getBenServiceList(@PathVariable("id") Long id) {
        LOG.debug("REST request to get BenServiceList : {}", id);
        Optional<BenServiceListDTO> benServiceListDTO = benServiceListService.findOne(id);
        return ResponseUtil.wrapOrNotFound(benServiceListDTO);
    }

    /**
     * {@code DELETE  /ben-service-lists/:id} : delete the "id" benServiceList.
     *
     * @param id the id of the benServiceListDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBenServiceList(@PathVariable("id") Long id) {
        LOG.debug("REST request to delete BenServiceList : {}", id);
        benServiceListService.delete(id);
        return ResponseEntity.noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, false, ENTITY_NAME, id.toString()))
            .build();
    }
}
