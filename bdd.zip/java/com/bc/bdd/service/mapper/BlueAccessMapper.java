package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.BlueAccess;
import com.bc.bdd.service.dto.BlueAccessDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link BlueAccess} and its DTO {@link BlueAccessDTO}.
 */
@Mapper(componentModel = "spring")
public interface BlueAccessMapper extends EntityMapper<BlueAccessDTO, BlueAccess> {}
