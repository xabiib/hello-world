



export interface Project {
    claimScenarioId: number;
    descriptionText?: string | null;
    userId?: string | null;
    privateInd?: string | null;
    lastUpdateDate?: string | null;
    lastupdatedby?: string | null;
  }
  
  /* export interface PaginatedProject extends PaginationModel {
    products: Project[]; */