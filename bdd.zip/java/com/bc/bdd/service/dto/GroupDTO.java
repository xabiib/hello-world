package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.Group} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class GroupDTO implements Serializable {

    private Long id;

    @NotNull
    @Size(max = 100)
    private String name;

    @Size(max = 5)
    private String num;

    private LocalDate effective;

    private LocalDate termination;

    @Size(max = 6)
    private String customerId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public LocalDate getEffective() {
        return effective;
    }

    public void setEffective(LocalDate effective) {
        this.effective = effective;
    }

    public LocalDate getTermination() {
        return termination;
    }

    public void setTermination(LocalDate termination) {
        this.termination = termination;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof GroupDTO)) {
            return false;
        }

        GroupDTO groupDTO = (GroupDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, groupDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "GroupDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", num='" + getNum() + "'" +
            ", effective='" + getEffective() + "'" +
            ", termination='" + getTermination() + "'" +
            ", customerId='" + getCustomerId() + "'" +
            "}";
    }
}
