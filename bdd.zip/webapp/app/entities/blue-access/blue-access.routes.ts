import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import BlueAccessResolve from './route/blue-access-routing-resolve.service';

const blueAccessRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/blue-access.component').then(m => m.BlueAccessComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/blue-access-detail.component').then(m => m.BlueAccessDetailComponent),
    resolve: {
      blueAccess: BlueAccessResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/blue-access-update.component').then(m => m.BlueAccessUpdateComponent),
    resolve: {
      blueAccess: BlueAccessResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    loadComponent: () => import('./update/blue-access-update.component').then(m => m.BlueAccessUpdateComponent),
    resolve: {
      blueAccess: BlueAccessResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default blueAccessRoute;
