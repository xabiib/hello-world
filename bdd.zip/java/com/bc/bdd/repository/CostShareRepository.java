package com.bc.bdd.repository;

import com.bc.bdd.domain.CostShare;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the CostShare entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CostShareRepository extends JpaRepository<CostShare, Long> {}
