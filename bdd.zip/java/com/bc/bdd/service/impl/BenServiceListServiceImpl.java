package com.bc.bdd.service.impl;

import com.bc.bdd.domain.BenServiceList;
import com.bc.bdd.repository.BenServiceListRepository;
import com.bc.bdd.service.BenServiceListService;
import com.bc.bdd.service.dto.BenServiceListDTO;
import com.bc.bdd.service.mapper.BenServiceListMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.BenServiceList}.
 */
@Service
@Transactional
public class BenServiceListServiceImpl implements BenServiceListService {

    private static final Logger LOG = LoggerFactory.getLogger(BenServiceListServiceImpl.class);

    private final BenServiceListRepository benServiceListRepository;

    private final BenServiceListMapper benServiceListMapper;

    public BenServiceListServiceImpl(BenServiceListRepository benServiceListRepository, BenServiceListMapper benServiceListMapper) {
        this.benServiceListRepository = benServiceListRepository;
        this.benServiceListMapper = benServiceListMapper;
    }

    @Override
    public BenServiceListDTO save(BenServiceListDTO benServiceListDTO) {
        LOG.debug("Request to save BenServiceList : {}", benServiceListDTO);
        BenServiceList benServiceList = benServiceListMapper.toEntity(benServiceListDTO);
        benServiceList = benServiceListRepository.save(benServiceList);
        return benServiceListMapper.toDto(benServiceList);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BenServiceListDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all BenServiceLists");
        return benServiceListRepository.findAll(pageable).map(benServiceListMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<BenServiceListDTO> findOne(Long id) {
        LOG.debug("Request to get BenServiceList : {}", id);
        return benServiceListRepository.findById(id).map(benServiceListMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete BenServiceList : {}", id);
        benServiceListRepository.deleteById(id);
    }

    @Override
    public BenServiceListDTO update(BenServiceListDTO benServiceListDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'update'");
    }

    @Override
    public Optional<BenServiceListDTO> partialUpdate(BenServiceListDTO benServiceListDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'partialUpdate'");
    }
}
