package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.Group;
import com.bc.bdd.domain.Section;
import com.bc.bdd.service.dto.GroupDTO;
import com.bc.bdd.service.dto.SectionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Section} and its DTO {@link SectionDTO}.
 */
@Mapper(componentModel = "spring")
public interface SectionMapper extends EntityMapper<SectionDTO, Section> {
    @Mapping(target = "group", source = "group", qualifiedByName = "groupNum")
    SectionDTO toDto(Section s);

    @Named("groupNum")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "num", source = "num")
    GroupDTO toDtoGroupNum(Group group);
}
