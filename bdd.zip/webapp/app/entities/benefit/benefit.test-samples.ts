import { IBenefit, NewBenefit } from './benefit.model';

export const sampleWithRequiredData: IBenefit = {
  id: 14420,
  name: 'nice',
};

export const sampleWithPartialData: IBenefit = {
  id: 15096,
  name: 'roam before only',
  type: 'FACILITY',
  seq: 20909,
  active: true,
};

export const sampleWithFullData: IBenefit = {
  id: 10663,
  name: 'far as',
  type: 'AUTISM',
  seq: 22343,
  active: true,
};

export const sampleWithNewData: NewBenefit = {
  name: 'tomorrow',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
