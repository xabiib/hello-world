package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.BlueAccess;
import com.bc.bdd.domain.Group;
import com.bc.bdd.domain.GroupAccess;
import com.bc.bdd.service.dto.BlueAccessDTO;
import com.bc.bdd.service.dto.GroupAccessDTO;
import com.bc.bdd.service.dto.GroupDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link GroupAccess} and its DTO {@link GroupAccessDTO}.
 */
@Mapper(componentModel = "spring")
public interface GroupAccessMapper extends EntityMapper<GroupAccessDTO, GroupAccess> {
    @Mapping(target = "group", source = "group", qualifiedByName = "groupNum")
    @Mapping(target = "blueAccess", source = "blueAccess", qualifiedByName = "blueAccessRole")
    GroupAccessDTO toDto(GroupAccess s);

    @Named("groupNum")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "num", source = "num")
    GroupDTO toDtoGroupNum(Group group);

    @Named("blueAccessRole")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "role", source = "role")
    BlueAccessDTO toDtoBlueAccessRole(BlueAccess blueAccess);
}
