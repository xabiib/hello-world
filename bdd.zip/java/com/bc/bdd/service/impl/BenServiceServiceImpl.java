package com.bc.bdd.service.impl;

import com.bc.bdd.domain.BenService;
import com.bc.bdd.repository.BenServiceRepository;
import com.bc.bdd.service.BenServiceService;
import com.bc.bdd.service.dto.BenServiceDTO;
import com.bc.bdd.service.mapper.BenServiceMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.BenService}.
 */
@Service
@Transactional
public class BenServiceServiceImpl implements BenServiceService {

    private static final Logger LOG = LoggerFactory.getLogger(BenServiceServiceImpl.class);

    private final BenServiceRepository benServiceRepository;

    private final BenServiceMapper benServiceMapper;

    public BenServiceServiceImpl(BenServiceRepository benServiceRepository, BenServiceMapper benServiceMapper) {
        this.benServiceRepository = benServiceRepository;
        this.benServiceMapper = benServiceMapper;
    }

    @Override
    public BenServiceDTO save(BenServiceDTO benServiceDTO) {
        LOG.debug("Request to save BenService : {}", benServiceDTO);
        BenService benService = benServiceMapper.toEntity(benServiceDTO);
        benService = benServiceRepository.save(benService);
        return benServiceMapper.toDto(benService);
    }

    @Override
    public BenServiceDTO update(BenServiceDTO benServiceDTO) {
        LOG.debug("Request to update BenService : {}", benServiceDTO);
        BenService benService = benServiceMapper.toEntity(benServiceDTO);
        benService = benServiceRepository.save(benService);
        return benServiceMapper.toDto(benService);
    }

    @Override
    public Optional<BenServiceDTO> partialUpdate(BenServiceDTO benServiceDTO) {
        LOG.debug("Request to partially update BenService : {}", benServiceDTO);

        return benServiceRepository
            .findById(benServiceDTO.getId())
            .map(existingBenService -> {
                benServiceMapper.partialUpdate(existingBenService, benServiceDTO);

                return existingBenService;
            })
            .map(benServiceRepository::save)
            .map(benServiceMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<BenServiceDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all BenServices");
        return benServiceRepository.findAll(pageable).map(benServiceMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<BenServiceDTO> findOne(Long id) {
        LOG.debug("Request to get BenService : {}", id);
        return benServiceRepository.findById(id).map(benServiceMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete BenService : {}", id);
        benServiceRepository.deleteById(id);
    }
}
