package com.bc.bdd.config;

import java.time.Duration;
import org.ehcache.config.builders.*;
import org.ehcache.jsr107.Eh107Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.cache.JCacheManagerCustomizer;
import org.springframework.boot.info.BuildProperties;
import org.springframework.boot.info.GitProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.*;
import tech.jhipster.config.JHipsterProperties;
import tech.jhipster.config.cache.PrefixedKeyGenerator;

@Configuration
@EnableCaching
public class CacheConfiguration {

    private GitProperties gitProperties;
    private BuildProperties buildProperties;
    private final javax.cache.configuration.Configuration<Object, Object> jcacheConfiguration;

    public CacheConfiguration(JHipsterProperties jHipsterProperties) {
        JHipsterProperties.Cache.Ehcache ehcache = jHipsterProperties.getCache().getEhcache();

        jcacheConfiguration = Eh107Configuration.fromEhcacheCacheConfiguration(
            CacheConfigurationBuilder.newCacheConfigurationBuilder(
                Object.class,
                Object.class,
                ResourcePoolsBuilder.heap(ehcache.getMaxEntries())
            )
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofSeconds(ehcache.getTimeToLiveSeconds())))
                .build()
        );
    }

    @Bean
    public JCacheManagerCustomizer cacheManagerCustomizer() {
        return cm -> {
            createCache(cm, com.bc.bdd.repository.UserRepository.USERS_BY_LOGIN_CACHE);
            createCache(cm, com.bc.bdd.repository.UserRepository.USERS_BY_EMAIL_CACHE);
            createCache(cm, com.bc.bdd.domain.Authority.class.getName());
            createCache(cm, com.bc.bdd.domain.Group.class.getName());
            createCache(cm, com.bc.bdd.domain.Section.class.getName());
            createCache(cm, com.bc.bdd.domain.PackageCode.class.getName());
            createCache(cm, com.bc.bdd.domain.PackagePlan.class.getName());
            createCache(cm, com.bc.bdd.domain.Plan.class.getName());
            createCache(cm, com.bc.bdd.domain.CostShare.class.getName());
            createCache(cm, com.bc.bdd.domain.CostShare.class.getName() + ".plans");
            createCache(cm, com.bc.bdd.domain.Benefit.class.getName());
            createCache(cm, com.bc.bdd.domain.BenService.class.getName());
            createCache(cm, com.bc.bdd.domain.BenServiceList.class.getName());
            createCache(cm, com.bc.bdd.domain.BenServiceList.class.getName() + ".benServices");
            createCache(cm, com.bc.bdd.domain.BenServiceList.class.getName() + ".plans");
            createCache(cm, com.bc.bdd.domain.BlueAccess.class.getName());
            createCache(cm, com.bc.bdd.domain.GroupAccess.class.getName());
            // jhipster-needle-ehcache-add-entry
        };
    }

    private void createCache(javax.cache.CacheManager cm, String cacheName) {
        javax.cache.Cache<Object, Object> cache = cm.getCache(cacheName);
        if (cache != null) {
            cache.clear();
        } else {
            cm.createCache(cacheName, jcacheConfiguration);
        }
    }

    @Autowired(required = false)
    public void setGitProperties(GitProperties gitProperties) {
        this.gitProperties = gitProperties;
    }

    @Autowired(required = false)
    public void setBuildProperties(BuildProperties buildProperties) {
        this.buildProperties = buildProperties;
    }

    @Bean
    public KeyGenerator keyGenerator() {
        return new PrefixedKeyGenerator(this.gitProperties, this.buildProperties);
    }
}
