/**
 * Application configuration.
 */
package com.bc.bdd.config;
