export interface IBenServiceList {
  id: number;
}

export type NewBenServiceList = Omit<IBenServiceList, 'id'> & { id: null };
