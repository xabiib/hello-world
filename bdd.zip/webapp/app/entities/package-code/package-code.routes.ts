import { Routes } from '@angular/router';

import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { ASC } from 'app/config/navigation.constants';
import PackageCodeResolve from './route/package-code-routing-resolve.service';

const packageCodeRoute: Routes = [
  {
    path: '',
    loadComponent: () => import('./list/package-code.component').then(m => m.PackageCodeComponent),
    data: {
      defaultSort: `id,${ASC}`,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/view',
    loadComponent: () => import('./detail/package-code-detail.component').then(m => m.PackageCodeDetailComponent),
    resolve: {
      packageCode: PackageCodeResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: 'new',
    loadComponent: () => import('./update/package-code-update.component').then(m => m.PackageCodeUpdateComponent),
    resolve: {
      packageCode: PackageCodeResolve,
    },
    canActivate: [UserRouteAccessService],
  },
  {
    path: ':id/edit',
    loadComponent: () => import('./update/package-code-update.component').then(m => m.PackageCodeUpdateComponent),
    resolve: {
      packageCode: PackageCodeResolve,
    },
    canActivate: [UserRouteAccessService],
  },
];

export default packageCodeRoute;
