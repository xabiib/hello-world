package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.Benefit;
import com.bc.bdd.service.dto.BenefitDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Benefit} and its DTO {@link BenefitDTO}.
 */
@Mapper(componentModel = "spring")
public interface BenefitMapper extends EntityMapper<BenefitDTO, Benefit> {}
