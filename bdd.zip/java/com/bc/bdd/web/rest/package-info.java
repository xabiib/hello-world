/**
 * Rest layer.
 */
package com.bc.bdd.web.rest;
