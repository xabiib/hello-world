/**
 * Application security utilities.
 */
package com.bc.bdd.security;
