import { Injectable, inject } from "@angular/core";
import { environment } from "../../environments/environment.development";
import { PaginatedProject, Project as Project } from "./project.model";
import { Observable, map } from "rxjs";
import { HttpClient, HttpParams } from "@angular/common/http";
import { PaginationModel } from "../shared/models/pagination.model";

@Injectable({
  providedIn: "root",
})
export class ProjectService {
  #http = inject(HttpClient);
 // #baseUrl = environment.API_BASE_URL + "/projects";

 #baseUrl =  'assets/project.json';

  addProject(project: Project): Observable<Project> {
    return this.#http.post<Project>(this.#baseUrl, project);
  }

  updateProject(project: Project): Observable<Project> {
    const url = `${this.#baseUrl}/${project.claimScenarioId}`;
    return this.#http.put<Project>(url, project);
  }

  deleteProject(id: number): Observable<any> {
    const url = `${this.#baseUrl}/${id}`;
    return this.#http.delete<any>(url);
  }

  getProject(id: number): Observable<Project> {
    const url = `${this.#baseUrl}/${id}`;
    return this.#http.get<Project>(url);
  }

  getProjects(
    page = 1,
    limit = 4,
    searchTerm: string | null = null,
    sortColumn: string | null = null,
    sortDirection: string | null = null
  ): Observable<PaginatedProject> {
    let parameters = new HttpParams();
    parameters = parameters.set("page", page);
    parameters = parameters.set("limit", limit);
    if (searchTerm) parameters = parameters.set("searchTerm", searchTerm);
    if (sortColumn) parameters = parameters.set("sortColumn", sortColumn);
    if (sortDirection)
      parameters = parameters.set("sortDirection", sortDirection);
    return this.#http
      .get(this.#baseUrl, {
        observe: "response",
        params: parameters,
      })
      .pipe(
        map((response) => {
          const paginationHeader = response.headers.get(
            "X-Pagination"
          ) as string;
          const paginationData: PaginationModel = JSON.parse(paginationHeader);
          let projects = response.body as Project[];
          if (searchTerm) {
          console.log('!!!!!!!!!!!!!!!!!!!!!!!!!!11' ) ;
          projects = projects.filter((prod) => prod.descriptionText?.includes(searchTerm));
          }
          else
          console.log('!$$$$$$$$$$$$$$$$$$$$$$$$$$!!11' ) ;
          const ProjectResponse: PaginatedProject = {
            ...paginationData,
            projects,
          };
          return ProjectResponse;
        })
      );
  }

 /*  getAllProjectsWithClaim(): Observable<ProjectWithClaim[]> {
    return this.#http.get<ProjectWithClaim[]>( 'assets/pstock.json'
      //this.#baseUrl + "/all-projecs-with-claim"
    );
  } */
}
