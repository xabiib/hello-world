package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.BenService;
import com.bc.bdd.domain.BenServiceList;
import com.bc.bdd.domain.Benefit;
import com.bc.bdd.service.dto.BenServiceDTO;
import com.bc.bdd.service.dto.BenServiceListDTO;
import com.bc.bdd.service.dto.BenefitDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link BenService} and its DTO {@link BenServiceDTO}.
 */
@Mapper(componentModel = "spring")
public interface BenServiceMapper extends EntityMapper<BenServiceDTO, BenService> {
    @Mapping(target = "benefit", source = "benefit", qualifiedByName = "benefitId")
    @Mapping(target = "benServiceList", source = "benServiceList", qualifiedByName = "benServiceListId")
    BenServiceDTO toDto(BenService s);

    @Named("benefitId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    BenefitDTO toDtoBenefitId(Benefit benefit);

    @Named("benServiceListId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    BenServiceListDTO toDtoBenServiceListId(BenServiceList benServiceList);
}
