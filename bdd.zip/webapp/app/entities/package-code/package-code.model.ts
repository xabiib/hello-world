import { ISection } from 'app/entities/section/section.model';

export interface IPackageCode {
  id: number;
  name?: string | null;
  num?: string | null;
  section?: Pick<ISection, 'id' | 'num'> | null;
}

export type NewPackageCode = Omit<IPackageCode, 'id'> & { id: null };
