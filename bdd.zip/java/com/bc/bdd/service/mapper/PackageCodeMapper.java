package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.PackageCode;
import com.bc.bdd.domain.Section;
import com.bc.bdd.service.dto.PackageCodeDTO;
import com.bc.bdd.service.dto.SectionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link PackageCode} and its DTO {@link PackageCodeDTO}.
 */
@Mapper(componentModel = "spring")
public interface PackageCodeMapper extends EntityMapper<PackageCodeDTO, PackageCode> {
    @Mapping(target = "section", source = "section", qualifiedByName = "sectionNum")
    PackageCodeDTO toDto(PackageCode s);

    @Named("sectionNum")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    @Mapping(target = "num", source = "num")
    SectionDTO toDtoSectionNum(Section section);
}
