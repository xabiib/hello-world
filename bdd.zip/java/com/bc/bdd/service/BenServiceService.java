package com.bc.bdd.service;

import com.bc.bdd.service.dto.BenServiceDTO;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * Service Interface for managing {@link com.bc.bdd.domain.BenService}.
 */
public interface BenServiceService {
    /**
     * Save a benService.
     *
     * @param benServiceDTO the entity to save.
     * @return the persisted entity.
     */
    BenServiceDTO save(BenServiceDTO benServiceDTO);

    /**
     * Updates a benService.
     *
     * @param benServiceDTO the entity to update.
     * @return the persisted entity.
     */
    BenServiceDTO update(BenServiceDTO benServiceDTO);

    /**
     * Partially updates a benService.
     *
     * @param benServiceDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<BenServiceDTO> partialUpdate(BenServiceDTO benServiceDTO);

    /**
     * Get all the benServices.
     *
     * @param pageable the pagination information.
     * @return the list of entities.
     */
    Page<BenServiceDTO> findAll(Pageable pageable);

    /**
     * Get the "id" benService.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<BenServiceDTO> findOne(Long id);

    /**
     * Delete the "id" benService.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
