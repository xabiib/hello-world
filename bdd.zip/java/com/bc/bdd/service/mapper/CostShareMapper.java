package com.bc.bdd.service.mapper;

import com.bc.bdd.domain.CostShare;
import com.bc.bdd.service.dto.CostShareDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link CostShare} and its DTO {@link CostShareDTO}.
 */
@Mapper(componentModel = "spring")
public interface CostShareMapper extends EntityMapper<CostShareDTO, CostShare> {}
