import dayjs from 'dayjs/esm';
import { IPackageCode } from 'app/entities/package-code/package-code.model';
import { IUser } from 'app/entities/user/user.model';
import { IPlan } from 'app/entities/plan/plan.model';

export interface IPackagePlan {
  id: number;
  name?: string | null;
  effective?: dayjs.Dayjs | null;
  termination?: dayjs.Dayjs | null;
  date?: dayjs.Dayjs | null;
  status?: string | null;
  packagecode?: Pick<IPackageCode, 'id' | 'num'> | null;
  user?: Pick<IUser, 'id' | 'login'> | null;
  plan?: Pick<IPlan, 'id' | 'name'> | null;
}

export type NewPackagePlan = Omit<IPackagePlan, 'id'> & { id: null };
