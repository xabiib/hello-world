import {
  ChangeDetectionStrategy,
  Component,
  OnDestroy,
  inject,
} from "@angular/core";
import { provideComponentStore } from "@ngrx/component-store";
import { ProjectStore } from "./project.store";
import { AsyncPipe, NgFor, NgIf } from "@angular/common";
import { Project } from "./project.model";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatDialog } from "@angular/material/dialog";
import { Subject, takeUntil, tap } from "rxjs";
import { MatButtonModule } from "@angular/material/button";
import { capitalize } from "../utils/init-cap.util";
import { ProjectDialogComponent } from "./ui/project-dialog.component";
import { ProjectListComponent } from "./ui/project-list.component";
import { FormBuilder, FormControl, FormGroup, FormsModule, ReactiveFormsModule } from "@angular/forms";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatSelectModule } from "@angular/material/select";
import { MatCardModule } from "@angular/material/card";
import { MatIconModule } from "@angular/material/icon";
import { ProjectService } from "./project.service";

@Component({
  selector: "app-project",
  standalone: true,
  imports: [
    NgIf,
    NgFor,
    AsyncPipe,
    ProjectListComponent,    
    MatProgressSpinnerModule,
    MatButtonModule,
    ReactiveFormsModule, MatFormFieldModule, MatInputModule,
      MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    FormsModule
  ],
  providers: [provideComponentStore(ProjectStore), ProjectService],
  templateUrl: "./project.component.html",
  styleUrls: ["./project.component.scss"],
})
export class ProjectComponent implements OnDestroy {
  dialog = inject(MatDialog);
  destroyed$ = new Subject<boolean>();
  projects$!: Project[];



  searchForm: FormGroup = this.fb.group({
    descriptionText: [null],
    userId: [null]
  });

  
  users = ['Habib', 'jagan', 'Rizwan', 'Salman' , 'Ibtisam', 'Sai'];

  onDelete(project: Project) {
    if (confirm("Are you sure to delete?")) {
      this.projectService.deleteProject(project.claimScenarioId).subscribe(data => {
        console.log('Deleted Project' + data);
      //  this.projects$ = data;
      })
    }
  }

  onAddUpdate(action: string, project: Project | null = null) {  
    const dialogRef = this.dialog.open(ProjectDialogComponent, {
      data: { project },
    });

    dialogRef.componentInstance.sumbit
      .pipe(takeUntil(this.destroyed$))
      .subscribe((submittedProject) => {
        if (!submittedProject) return;
        if (
          submittedProject.claimScenarioId &&
          submittedProject.claimScenarioId > 0
        ) {
          this.projectService.updateProject(submittedProject).subscribe(data => {
            console.log('Updated Project' + data);
          //  this.projects$ = data;
          })
        } else {
          this.projectService.updateProject(submittedProject).subscribe(data => {
            console.log('New Project' + data);
          //  this.projects$ = data;
          })
        }
        dialogRef.componentInstance.projectForm.reset();
        dialogRef.componentInstance.onCanceled();
      });
  }

  constructor(private fb: FormBuilder , private projectService: ProjectService) {
    this.projectService.getAllProjects().subscribe(data => {
      console.log('Sratoooooooo ' + data);
      this.projects$ = data;
    })
  }
  ngOnDestroy(): void {
    this.destroyed$.next(true);
    this.destroyed$.unsubscribe();
  }

  ngOnInit() {
    this.projectService.getAllProjects().subscribe(data => {
      console.log(data);
      this.projects$ = data;
    })
  }

  
  onSearch1() {
    console.log('Searching for:', this.searchForm.value);
    this.projectService.searchProjects( this.searchForm.value).subscribe(data => {
      console.log(data);
      this.projects$ = data;
    })
  }
}
