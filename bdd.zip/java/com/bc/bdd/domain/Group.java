package com.bc.bdd.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * A Group.
 */
@Entity
@Table(name = "jhi_group")
@SuppressWarnings("common-java:DuplicatedBlocks")
public class Group implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "name", length = 100, nullable = false)
    private String name;

    @Size(max = 5)
    @Column(name = "num", length = 5)
    private String num;

    @Column(name = "effective")
    private LocalDate effective;

    @Column(name = "termination")
    private LocalDate termination;

    @Size(max = 6)
    @Column(name = "customer_id", length = 6)
    private String customerId;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public Group id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public Group name(String name) {
        this.setName(name);
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return this.num;
    }

    public Group num(String num) {
        this.setNum(num);
        return this;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public LocalDate getEffective() {
        return this.effective;
    }

    public Group effective(LocalDate effective) {
        this.setEffective(effective);
        return this;
    }

    public void setEffective(LocalDate effective) {
        this.effective = effective;
    }

    public LocalDate getTermination() {
        return this.termination;
    }

    public Group termination(LocalDate termination) {
        this.setTermination(termination);
        return this;
    }

    public void setTermination(LocalDate termination) {
        this.termination = termination;
    }

    public String getCustomerId() {
        return this.customerId;
    }

    public Group customerId(String customerId) {
        this.setCustomerId(customerId);
        return this;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Group)) {
            return false;
        }
        return getId() != null && getId().equals(((Group) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Group{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", num='" + getNum() + "'" +
            ", effective='" + getEffective() + "'" +
            ", termination='" + getTermination() + "'" +
            ", customerId='" + getCustomerId() + "'" +
            "}";
    }
}
