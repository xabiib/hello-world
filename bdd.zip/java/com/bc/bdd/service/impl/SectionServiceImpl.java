package com.bc.bdd.service.impl;

import com.bc.bdd.domain.Section;
import com.bc.bdd.repository.SectionRepository;
import com.bc.bdd.service.SectionService;
import com.bc.bdd.service.dto.SectionDTO;
import com.bc.bdd.service.mapper.SectionMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.Section}.
 */
@Service
@Transactional
public class SectionServiceImpl implements SectionService {

    private static final Logger LOG = LoggerFactory.getLogger(SectionServiceImpl.class);

    private final SectionRepository sectionRepository;

    private final SectionMapper sectionMapper;

    public SectionServiceImpl(SectionRepository sectionRepository, SectionMapper sectionMapper) {
        this.sectionRepository = sectionRepository;
        this.sectionMapper = sectionMapper;
    }

    @Override
    public SectionDTO save(SectionDTO sectionDTO) {
        LOG.debug("Request to save Section : {}", sectionDTO);
        Section section = sectionMapper.toEntity(sectionDTO);
        section = sectionRepository.save(section);
        return sectionMapper.toDto(section);
    }

    @Override
    public SectionDTO update(SectionDTO sectionDTO) {
        LOG.debug("Request to update Section : {}", sectionDTO);
        Section section = sectionMapper.toEntity(sectionDTO);
        section = sectionRepository.save(section);
        return sectionMapper.toDto(section);
    }

    @Override
    public Optional<SectionDTO> partialUpdate(SectionDTO sectionDTO) {
        LOG.debug("Request to partially update Section : {}", sectionDTO);

        return sectionRepository
            .findById(sectionDTO.getId())
            .map(existingSection -> {
                sectionMapper.partialUpdate(existingSection, sectionDTO);

                return existingSection;
            })
            .map(sectionRepository::save)
            .map(sectionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<SectionDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all Sections");
        return sectionRepository.findAll(pageable).map(sectionMapper::toDto);
    }

    public Page<SectionDTO> findAllWithEagerRelationships(Pageable pageable) {
        return sectionRepository.findAllWithEagerRelationships(pageable).map(sectionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<SectionDTO> findOne(Long id) {
        LOG.debug("Request to get Section : {}", id);
        return sectionRepository.findOneWithEagerRelationships(id).map(sectionMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete Section : {}", id);
        sectionRepository.deleteById(id);
    }
}
