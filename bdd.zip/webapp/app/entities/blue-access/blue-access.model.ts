export interface IBlueAccess {
  id: number;
  name?: string | null;
  role?: string | null;
}

export type NewBlueAccess = Omit<IBlueAccess, 'id'> & { id: null };
