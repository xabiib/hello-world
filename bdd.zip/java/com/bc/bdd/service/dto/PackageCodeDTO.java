package com.bc.bdd.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.bc.bdd.domain.PackageCode} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class PackageCodeDTO implements Serializable {

    private Long id;

    @Size(max = 100)
    private String name;

    @NotNull
    @Size(max = 3)
    private String num;

    private SectionDTO section;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public SectionDTO getSection() {
        return section;
    }

    public void setSection(SectionDTO section) {
        this.section = section;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PackageCodeDTO)) {
            return false;
        }

        PackageCodeDTO packageCodeDTO = (PackageCodeDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, packageCodeDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "PackageCodeDTO{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", num='" + getNum() + "'" +
            ", section=" + getSection() +
            "}";
    }
}
