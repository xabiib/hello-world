import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  Output,
} from "@angular/core";
import { Project } from "../project.model";
import { MatTableModule } from "@angular/material/table";
import { MatButtonModule } from "@angular/material/button";
import { MatIconModule } from "@angular/material/icon";
import { DatePipe } from "@angular/common";
import { MatSortModule, Sort } from "@angular/material/sort";

@Component({
  selector: "app-project-list",
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    DatePipe,
    MatSortModule,
  ],
  styles: [``],
  template: `
    <table
      style=" margin-top: 1.5rem;"
      mat-table
      [dataSource]="projects"
      class="mat-elevation-z8"
      matSort
      (matSortChange)="onSortData($event)"
    >
      <ng-container matColumnDef="descriptionText">
        <th
          mat-header-cell
          *matHeaderCellDef
          mat-sort-header
          sortActionDescription="sort by descriptionText"
        >
          Project
        </th>
        <td mat-cell *matCellDef="let element">
          {{ element.descriptionText }}
        </td>
      </ng-container>
      <ng-container matColumnDef="privateInd">
        <th
          mat-header-cell
          *matHeaderCellDef
          mat-sort-header
          sortActionDescription="sort by privateInd"
        >
          Private Ind
        </th>
        <td mat-cell *matCellDef="let element">{{ element.privateInd }}</td>
      </ng-container>
      <ng-container matColumnDef="userId">
        <th
          mat-header-cell
          *matHeaderCellDef
          mat-sort-header
          sortActionDescription="sort by userId"
        >
          User ID
        </th>
        <td mat-cell *matCellDef="let element">
          {{ element.userId }}
        </td>
      </ng-container>

      <ng-container matColumnDef="lastUpdateDate">
        <th
          mat-header-cell
          *matHeaderCellDef
          mat-sort-header
          sortActionDescription="sort by lastUpdateDate"
        >
          Create Date
        </th>
        <td mat-cell *matCellDef="let element">
          {{ element.lastUpdateDate | date : "dd-MMM-yyy HH:MM" }}
        </td>
      </ng-container>

      <ng-container matColumnDef="updateDate">
        <th
          mat-header-cell
          *matHeaderCellDef
          mat-sort-header
          sortActionDescription="sort by title"
        >
          Update Date
        </th>
        <td mat-cell *matCellDef="let element">
          {{ element.updateDate | date : "dd-MMM-yyy HH:MM" }}
        </td>
      </ng-container>

      <ng-container matColumnDef="action">
        <th mat-header-cell *matHeaderCellDef>Action</th>
        <td mat-cell *matCellDef="let element">
          <div style="display: flex;gap:5px;align-items:center">
            <button
              mat-mini-fab
              color="primary"
              aria-label="Edit"
              (click)="edit.emit(element)"
            >
              <mat-icon>edit</mat-icon>
            </button>

            <button
              mat-mini-fab
              color="warn"
              aria-label="Delete"
              (click)="delete.emit(element)"
            >
              <mat-icon>delete</mat-icon>
            </button>
          </div>
        </td>
      </ng-container>

      <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
      <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
    </table>
  `,
})
export class ProjectListComponent {
  @Input({ required: true }) projects!: Project[];
  @Output() delete = new EventEmitter<Project>();
  @Output() edit = new EventEmitter<Project>();
  @Output() sort = new EventEmitter<{
    sortColumn: string;
    sortDirection: "asc" | "desc";
  }>();

  displayedColumns = [
    "descriptionText",
    "privateInd",
    "lastUpdateDate",
   // "lastupdatedby",
    "userId",
    "action",
  ];

  onSortData(sortData: Sort) {
    const sortColumn = sortData.active;
    const sortDirection = sortData.direction as "asc" | "desc";
    console.log('@@@@@@@@@@@@@' + sortColumn) ;
    this.sort.emit({ sortColumn, sortDirection });
  }
}
