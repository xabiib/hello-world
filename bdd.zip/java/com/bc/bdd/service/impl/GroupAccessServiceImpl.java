package com.bc.bdd.service.impl;

import com.bc.bdd.domain.GroupAccess;
import com.bc.bdd.repository.GroupAccessRepository;
import com.bc.bdd.service.GroupAccessService;
import com.bc.bdd.service.dto.GroupAccessDTO;
import com.bc.bdd.service.mapper.GroupAccessMapper;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.bc.bdd.domain.GroupAccess}.
 */
@Service
@Transactional
public class GroupAccessServiceImpl implements GroupAccessService {

    private static final Logger LOG = LoggerFactory.getLogger(GroupAccessServiceImpl.class);

    private final GroupAccessRepository groupAccessRepository;

    private final GroupAccessMapper groupAccessMapper;

    public GroupAccessServiceImpl(GroupAccessRepository groupAccessRepository, GroupAccessMapper groupAccessMapper) {
        this.groupAccessRepository = groupAccessRepository;
        this.groupAccessMapper = groupAccessMapper;
    }

    @Override
    public GroupAccessDTO save(GroupAccessDTO groupAccessDTO) {
        LOG.debug("Request to save GroupAccess : {}", groupAccessDTO);
        GroupAccess groupAccess = groupAccessMapper.toEntity(groupAccessDTO);
        groupAccess = groupAccessRepository.save(groupAccess);
        return groupAccessMapper.toDto(groupAccess);
    }

    @Override
    public GroupAccessDTO update(GroupAccessDTO groupAccessDTO) {
        LOG.debug("Request to update GroupAccess : {}", groupAccessDTO);
        GroupAccess groupAccess = groupAccessMapper.toEntity(groupAccessDTO);
        groupAccess = groupAccessRepository.save(groupAccess);
        return groupAccessMapper.toDto(groupAccess);
    }

    @Override
    public Optional<GroupAccessDTO> partialUpdate(GroupAccessDTO groupAccessDTO) {
        LOG.debug("Request to partially update GroupAccess : {}", groupAccessDTO);

        return groupAccessRepository
            .findById(groupAccessDTO.getId())
            .map(existingGroupAccess -> {
                groupAccessMapper.partialUpdate(existingGroupAccess, groupAccessDTO);

                return existingGroupAccess;
            })
            .map(groupAccessRepository::save)
            .map(groupAccessMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<GroupAccessDTO> findAll(Pageable pageable) {
        LOG.debug("Request to get all GroupAccesses");
        return groupAccessRepository.findAll(pageable).map(groupAccessMapper::toDto);
    }

    public Page<GroupAccessDTO> findAllWithEagerRelationships(Pageable pageable) {
        return groupAccessRepository.findAllWithEagerRelationships(pageable).map(groupAccessMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<GroupAccessDTO> findOne(Long id) {
        LOG.debug("Request to get GroupAccess : {}", id);
        return groupAccessRepository.findOneWithEagerRelationships(id).map(groupAccessMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        LOG.debug("Request to delete GroupAccess : {}", id);
        groupAccessRepository.deleteById(id);
    }
}
