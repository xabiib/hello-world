import dayjs from 'dayjs/esm';

import { IGroup, NewGroup } from './group.model';

export const sampleWithRequiredData: IGroup = {
  id: 13489,
  name: 'slam between',
};

export const sampleWithPartialData: IGroup = {
  id: 30551,
  name: 'er easy-going',
  num: 'acqui',
  effective: dayjs('2024-09-02'),
  termination: dayjs('2024-09-02'),
};

export const sampleWithFullData: IGroup = {
  id: 14834,
  name: 'around',
  num: 'ram l',
  effective: dayjs('2024-09-01'),
  termination: dayjs('2024-09-01'),
  customerId: 'before',
};

export const sampleWithNewData: NewGroup = {
  name: 'humongous',
  id: null,
};

Object.freeze(sampleWithNewData);
Object.freeze(sampleWithRequiredData);
Object.freeze(sampleWithPartialData);
Object.freeze(sampleWithFullData);
