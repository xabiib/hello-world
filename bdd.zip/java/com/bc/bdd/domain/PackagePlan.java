package com.bc.bdd.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;

/**
 * A PackagePlan.
 */
@Entity
@Table(name = "package_plan")
@SuppressWarnings("common-java:DuplicatedBlocks")
public class PackagePlan implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @Size(max = 100)
    @Column(name = "name", length = 100)
    private String name;

    @Column(name = "effective")
    private LocalDate effective;

    @Column(name = "termination")
    private LocalDate termination;

    @Column(name = "jhi_date")
    private Instant date;

    @Size(max = 10)
    @Column(name = "status", length = 10)
    private String status;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "section" }, allowSetters = true)
    private PackageCode packagecode;

    @ManyToOne(fetch = FetchType.LAZY)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "costShare", "benServiceList" }, allowSetters = true)
    private Plan plan;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public PackagePlan id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return this.name;
    }

    public PackagePlan name(String name) {
        this.setName(name);
        return this;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getEffective() {
        return this.effective;
    }

    public PackagePlan effective(LocalDate effective) {
        this.setEffective(effective);
        return this;
    }

    public void setEffective(LocalDate effective) {
        this.effective = effective;
    }

    public LocalDate getTermination() {
        return this.termination;
    }

    public PackagePlan termination(LocalDate termination) {
        this.setTermination(termination);
        return this;
    }

    public void setTermination(LocalDate termination) {
        this.termination = termination;
    }

    public Instant getDate() {
        return this.date;
    }

    public PackagePlan date(Instant date) {
        this.setDate(date);
        return this;
    }

    public void setDate(Instant date) {
        this.date = date;
    }

    public String getStatus() {
        return this.status;
    }

    public PackagePlan status(String status) {
        this.setStatus(status);
        return this;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public PackageCode getPackagecode() {
        return this.packagecode;
    }

    public void setPackagecode(PackageCode packageCode) {
        this.packagecode = packageCode;
    }

    public PackagePlan packagecode(PackageCode packageCode) {
        this.setPackagecode(packageCode);
        return this;
    }

    public User getUser() {
        return this.user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public PackagePlan user(User user) {
        this.setUser(user);
        return this;
    }

    public Plan getPlan() {
        return this.plan;
    }

    public void setPlan(Plan plan) {
        this.plan = plan;
    }

    public PackagePlan plan(Plan plan) {
        this.setPlan(plan);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof PackagePlan)) {
            return false;
        }
        return getId() != null && getId().equals(((PackagePlan) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "PackagePlan{" +
            "id=" + getId() +
            ", name='" + getName() + "'" +
            ", effective='" + getEffective() + "'" +
            ", termination='" + getTermination() + "'" +
            ", date='" + getDate() + "'" +
            ", status='" + getStatus() + "'" +
            "}";
    }
}
