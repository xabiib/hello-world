import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpResponse, provideHttpClient } from '@angular/common/http';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Subject, from, of } from 'rxjs';

import { IPackageCode } from 'app/entities/package-code/package-code.model';
import { PackageCodeService } from 'app/entities/package-code/service/package-code.service';
import { IUser } from 'app/entities/user/user.model';
import { UserService } from 'app/entities/user/service/user.service';
import { IPlan } from 'app/entities/plan/plan.model';
import { PlanService } from 'app/entities/plan/service/plan.service';
import { IPackagePlan } from '../package-plan.model';
import { PackagePlanService } from '../service/package-plan.service';
import { PackagePlanFormService } from './package-plan-form.service';

import { PackagePlanUpdateComponent } from './package-plan-update.component';

describe('PackagePlan Management Update Component', () => {
  let comp: PackagePlanUpdateComponent;
  let fixture: ComponentFixture<PackagePlanUpdateComponent>;
  let activatedRoute: ActivatedRoute;
  let packagePlanFormService: PackagePlanFormService;
  let packagePlanService: PackagePlanService;
  let packageCodeService: PackageCodeService;
  let userService: UserService;
  let planService: PlanService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [PackagePlanUpdateComponent],
      providers: [
        provideHttpClient(),
        FormBuilder,
        {
          provide: ActivatedRoute,
          useValue: {
            params: from([{}]),
          },
        },
      ],
    })
      .overrideTemplate(PackagePlanUpdateComponent, '')
      .compileComponents();

    fixture = TestBed.createComponent(PackagePlanUpdateComponent);
    activatedRoute = TestBed.inject(ActivatedRoute);
    packagePlanFormService = TestBed.inject(PackagePlanFormService);
    packagePlanService = TestBed.inject(PackagePlanService);
    packageCodeService = TestBed.inject(PackageCodeService);
    userService = TestBed.inject(UserService);
    planService = TestBed.inject(PlanService);

    comp = fixture.componentInstance;
  });

  describe('ngOnInit', () => {
    it('Should call PackageCode query and add missing value', () => {
      const packagePlan: IPackagePlan = { id: 456 };
      const packagecode: IPackageCode = { id: 4844 };
      packagePlan.packagecode = packagecode;

      const packageCodeCollection: IPackageCode[] = [{ id: 10701 }];
      jest.spyOn(packageCodeService, 'query').mockReturnValue(of(new HttpResponse({ body: packageCodeCollection })));
      const additionalPackageCodes = [packagecode];
      const expectedCollection: IPackageCode[] = [...additionalPackageCodes, ...packageCodeCollection];
      jest.spyOn(packageCodeService, 'addPackageCodeToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ packagePlan });
      comp.ngOnInit();

      expect(packageCodeService.query).toHaveBeenCalled();
      expect(packageCodeService.addPackageCodeToCollectionIfMissing).toHaveBeenCalledWith(
        packageCodeCollection,
        ...additionalPackageCodes.map(expect.objectContaining),
      );
      expect(comp.packageCodesSharedCollection).toEqual(expectedCollection);
    });

    it('Should call User query and add missing value', () => {
      const packagePlan: IPackagePlan = { id: 456 };
      const user: IUser = { id: 30078 };
      packagePlan.user = user;

      const userCollection: IUser[] = [{ id: 29367 }];
      jest.spyOn(userService, 'query').mockReturnValue(of(new HttpResponse({ body: userCollection })));
      const additionalUsers = [user];
      const expectedCollection: IUser[] = [...additionalUsers, ...userCollection];
      jest.spyOn(userService, 'addUserToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ packagePlan });
      comp.ngOnInit();

      expect(userService.query).toHaveBeenCalled();
      expect(userService.addUserToCollectionIfMissing).toHaveBeenCalledWith(
        userCollection,
        ...additionalUsers.map(expect.objectContaining),
      );
      expect(comp.usersSharedCollection).toEqual(expectedCollection);
    });

    it('Should call Plan query and add missing value', () => {
      const packagePlan: IPackagePlan = { id: 456 };
      const plan: IPlan = { id: 17837 };
      packagePlan.plan = plan;

      const planCollection: IPlan[] = [{ id: 12492 }];
      jest.spyOn(planService, 'query').mockReturnValue(of(new HttpResponse({ body: planCollection })));
      const additionalPlans = [plan];
      const expectedCollection: IPlan[] = [...additionalPlans, ...planCollection];
      jest.spyOn(planService, 'addPlanToCollectionIfMissing').mockReturnValue(expectedCollection);

      activatedRoute.data = of({ packagePlan });
      comp.ngOnInit();

      expect(planService.query).toHaveBeenCalled();
      expect(planService.addPlanToCollectionIfMissing).toHaveBeenCalledWith(
        planCollection,
        ...additionalPlans.map(expect.objectContaining),
      );
      expect(comp.plansSharedCollection).toEqual(expectedCollection);
    });

    it('Should update editForm', () => {
      const packagePlan: IPackagePlan = { id: 456 };
      const packagecode: IPackageCode = { id: 23674 };
      packagePlan.packagecode = packagecode;
      const user: IUser = { id: 22076 };
      packagePlan.user = user;
      const plan: IPlan = { id: 14319 };
      packagePlan.plan = plan;

      activatedRoute.data = of({ packagePlan });
      comp.ngOnInit();

      expect(comp.packageCodesSharedCollection).toContain(packagecode);
      expect(comp.usersSharedCollection).toContain(user);
      expect(comp.plansSharedCollection).toContain(plan);
      expect(comp.packagePlan).toEqual(packagePlan);
    });
  });

  describe('save', () => {
    it('Should call update service on save for existing entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IPackagePlan>>();
      const packagePlan = { id: 123 };
      jest.spyOn(packagePlanFormService, 'getPackagePlan').mockReturnValue(packagePlan);
      jest.spyOn(packagePlanService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ packagePlan });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: packagePlan }));
      saveSubject.complete();

      // THEN
      expect(packagePlanFormService.getPackagePlan).toHaveBeenCalled();
      expect(comp.previousState).toHaveBeenCalled();
      expect(packagePlanService.update).toHaveBeenCalledWith(expect.objectContaining(packagePlan));
      expect(comp.isSaving).toEqual(false);
    });

    it('Should call create service on save for new entity', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IPackagePlan>>();
      const packagePlan = { id: 123 };
      jest.spyOn(packagePlanFormService, 'getPackagePlan').mockReturnValue({ id: null });
      jest.spyOn(packagePlanService, 'create').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ packagePlan: null });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.next(new HttpResponse({ body: packagePlan }));
      saveSubject.complete();

      // THEN
      expect(packagePlanFormService.getPackagePlan).toHaveBeenCalled();
      expect(packagePlanService.create).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).toHaveBeenCalled();
    });

    it('Should set isSaving to false on error', () => {
      // GIVEN
      const saveSubject = new Subject<HttpResponse<IPackagePlan>>();
      const packagePlan = { id: 123 };
      jest.spyOn(packagePlanService, 'update').mockReturnValue(saveSubject);
      jest.spyOn(comp, 'previousState');
      activatedRoute.data = of({ packagePlan });
      comp.ngOnInit();

      // WHEN
      comp.save();
      expect(comp.isSaving).toEqual(true);
      saveSubject.error('This is an error!');

      // THEN
      expect(packagePlanService.update).toHaveBeenCalled();
      expect(comp.isSaving).toEqual(false);
      expect(comp.previousState).not.toHaveBeenCalled();
    });
  });

  describe('Compare relationships', () => {
    describe('comparePackageCode', () => {
      it('Should forward to packageCodeService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(packageCodeService, 'comparePackageCode');
        comp.comparePackageCode(entity, entity2);
        expect(packageCodeService.comparePackageCode).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('compareUser', () => {
      it('Should forward to userService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(userService, 'compareUser');
        comp.compareUser(entity, entity2);
        expect(userService.compareUser).toHaveBeenCalledWith(entity, entity2);
      });
    });

    describe('comparePlan', () => {
      it('Should forward to planService', () => {
        const entity = { id: 123 };
        const entity2 = { id: 456 };
        jest.spyOn(planService, 'comparePlan');
        comp.comparePlan(entity, entity2);
        expect(planService.comparePlan).toHaveBeenCalledWith(entity, entity2);
      });
    });
  });
});
